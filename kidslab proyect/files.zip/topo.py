# 🐾 Función del Topo
# El Topo vive en una cueva húmeda y mide la pérdida de paquetes.
# Si la humedad es alta, los paquetes se pierden más.
# ¡Ayudá al Topo a calcular bien la pérdida!

def perdida_topo(humedad):
    # El Topo siempre pierde el 30%... demasiado!
    # Si la humedad es mayor a 70, debería devolver 5.
    # Si la humedad es menor o igual a 70, debería devolver 2.
    return 30


# ── Prueba rápida ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Humedad 80:", perdida_topo(80), "% — debería ser 5")
    print("Humedad 30:", perdida_topo(30), "% — debería ser 2")
    print("Humedad 100:", perdida_topo(100), "% — debería ser 5")

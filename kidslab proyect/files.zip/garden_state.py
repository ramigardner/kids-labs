"""
garden_state.py — Estado del Jardín de Confianza
Simula 4 animales-científicos con karma ASPR simplificado para niños.
"""
import random
import time
from datetime import datetime, timezone
from collections import deque

# ── Definición de animales ───────────────────────────────────────────────────
ANIMAL_DEFS = {
    "buho": {
        "name": "Búho",
        "emoji": "🦉",
        "role": "Observador nocturno",
        "color": "#7F77DD",
        "color_light": "#EEEDFE",
        "desc": "Mira desde lo alto y reporta cuántas estrellas ve.",
    },
    "zorro": {
        "name": "Zorro",
        "emoji": "🦊",
        "role": "Mensajero veloz",
        "color": "#D85A30",
        "color_light": "#FAECE7",
        "desc": "Lleva mensajes entre los animales del bosque.",
    },
    "topo": {
        "name": "Topo",
        "emoji": "🐾",
        "role": "Sensor subterráneo",
        "color": "#888780",
        "color_light": "#F1EFE8",
        "desc": "Mide la humedad del suelo desde su cueva.",
    },
    "abeja": {
        "name": "Abeja",
        "emoji": "🐝",
        "role": "Recolectora de datos",
        "color": "#BA7517",
        "color_light": "#FAEEDA",
        "desc": "Cuenta flores y polinizadores en el jardín.",
    },
}

WEATHERS = ["☀️ soleado", "🌧️ lluvia", "🌤️ nublado", "⛅ parcial", "❄️ frío"]

# ── Peso de la fórmula karma (idéntico al Oracle real) ───────────────────────
W = {"memoria": 0.30, "ciclos": 0.25, "anclaje": 0.20, "eficiencia": 0.15, "corrección": 0.10}


class Animal:
    def __init__(self, aid: str):
        self.id          = aid
        self.meta        = ANIMAL_DEFS[aid]
        self.latency     = random.uniform(15, 60)
        self.loss        = random.uniform(0, 5)
        self.online      = True
        self.noise       = False          # "grita un número raro"
        self.offline_evt = False          # forzado offline temporalmente
        self.karma       = 0.80
        self.components  = {}
        self.history     = deque(maxlen=60)   # últimos N karma values
        self.reports     = deque(maxlen=20)   # últimos reportes
        self.stars       = 4
        # Función de reporte personalizable por los niños
        self._report_fn  = None

    # ── Cálculo de karma ─────────────────────────────────────────────────────
    def calc_karma(self, clima: str) -> float:
        lat   = self.latency
        loss  = self.loss
        h     = list(self.history)

        # Memoria: qué tan estable fue en el pasado
        if len(h) < 4:
            mem = 0.5
        else:
            half = len(h) // 2
            f = sum(1 for k in h[:half] if k > 0.4) / half
            s = sum(1 for k in h[half:] if k > 0.4) / (len(h) - half)
            mem = min(1.0, 1.0 - abs(s - f) + 0.1) if s > f else 1.0 - abs(s - f)

        # Ciclos: % de veces que estuvo online
        cyc = max(0.0, 1.0 - loss / 100.0)

        # Anclaje: coincidencia con "dato del tiempo real" (clima)
        anc = 0.9 if "lluvia" not in clima else (0.7 if self.noise else 0.95)

        # Eficiencia: latencia y pérdida bajas = mejor
        eff = (max(0, 1 - lat / 250) + max(0, 1 - loss / 100)) / 2

        # Corrección: ¿se recuperó de errores?
        cor = 0.2 if self.noise else (0.5 if not self.online else 1.0)

        if not self.online:
            mem, cyc, eff, cor = 0.0, 0.0, 0.0, 0.0

        self.components = {
            "memoria":    round(mem, 3),
            "ciclos":     round(cyc, 3),
            "anclaje":    round(anc, 3),
            "eficiencia": round(eff, 3),
            "corrección": round(cor, 3),
        }

        k = sum(self.components[comp] * W[comp] for comp in W)
        self.karma = round(min(1.0, max(0.0, k)), 3)
        self.stars  = max(0, min(5, round(self.karma * 5)))
        return self.karma

    def generate_report(self, clima: str, ciclo: int) -> dict:
        """Genera el reporte del animal para este ciclo."""
        if self._report_fn:
            try:
                valor = float(self._report_fn(clima))
            except Exception:
                valor = round(random.uniform(1, 10), 1)
        else:
            base = {"buho": 7, "zorro": 5, "topo": 4, "abeja": 8}.get(self.id, 5)
            valor = round(base + random.uniform(-2, 2) + (3 if "lluvia" in clima else 0), 1)
            if self.noise:
                valor = round(random.uniform(50, 99), 1)   # número raro

        report = {
            "ciclo":  ciclo,
            "valor":  valor,
            "clima":  clima,
            "karma":  self.karma,
            "ts":     datetime.now().strftime("%H:%M:%S"),
            "online": self.online,
            "noise":  self.noise,
        }
        self.reports.appendleft(report)
        return report

    def tick(self, clima: str, ciclo: int) -> dict:
        """Un ciclo de observación completo."""
        if not self.online:
            self.latency = 999
            self.loss    = 100
        else:
            self.latency = max(5, self.latency + random.uniform(-8, 10))
            self.loss    = max(0, min(40, self.loss + random.uniform(-2, 3)))
            if self.noise:
                self.latency += random.uniform(60, 120)
                self.loss    += random.uniform(15, 30)

        self.calc_karma(clima)
        self.history.append(self.karma)
        return self.generate_report(clima, ciclo)

    def to_dict(self) -> dict:
        return {
            "id":         self.id,
            "name":       self.meta["name"],
            "emoji":      self.meta["emoji"],
            "role":       self.meta["role"],
            "desc":       self.meta["desc"],
            "color":      self.meta["color"],
            "color_light":self.meta["color_light"],
            "karma":      self.karma,
            "components": self.components,
            "latency":    round(self.latency, 1),
            "loss":       round(self.loss, 1),
            "online":     self.online,
            "noise":      self.noise,
            "stars":      self.stars,
            "history":    [{"t": i, "k": k} for i, k in enumerate(self.history)],
            "reports":    list(self.reports)[:5],
        }


class GardenState:
    def __init__(self):
        self.animals  = {aid: Animal(aid) for aid in ANIMAL_DEFS}
        self.cycle    = 0
        self.events   = deque(maxlen=40)
        self.clima    = "☀️ soleado"
        self._last_tick = 0

        # Arrancar con historial
        for _ in range(8):
            self._do_tick()

    def _do_tick(self):
        self.cycle += 1
        self.clima  = random.choice(WEATHERS)
        reports     = {}
        for aid, animal in self.animals.items():
            reports[aid] = animal.tick(self.clima, self.cycle)

        self._log(f"Ciclo {self.cycle} · {self.clima}", "ok")
        return reports

    def tick(self):
        """Llamado periódicamente por SocketIO."""
        now = time.time()
        if now - self._last_tick < 3:
            return None
        self._last_tick = now
        return self._do_tick()

    def force_tick(self):
        return self._do_tick()

    def _log(self, msg: str, kind: str = "info"):
        self.events.appendleft({
            "t":    datetime.now().strftime("%H:%M:%S"),
            "msg":  msg,
            "kind": kind,
        })

    # ── Acciones desde el dashboard ─────────────────────────────────────────

    def set_noise(self, aid: str, active: bool):
        if aid in self.animals:
            self.animals[aid].noise = active
            status = "activó ruido 📢" if active else "dejó de hacer ruido ✓"
            self._log(f"{self.animals[aid].meta['name']} {status}", "warn" if active else "ok")

    def set_online(self, aid: str, online: bool):
        if aid in self.animals:
            self.animals[aid].online = online
            status = "desconectado 🔴" if not online else "reconectado 🟢"
            self._log(f"{self.animals[aid].meta['name']} {status}", "crisis" if not online else "ok")

    def set_latency(self, aid: str, value: float):
        if aid in self.animals:
            self.animals[aid].latency = max(5, float(value))
            self._log(f"Latencia de {self.animals[aid].meta['name']} → {value:.0f}ms", "info")

    def set_report_fn(self, aid: str, fn):
        if aid in self.animals:
            self.animals[aid]._report_fn = fn
            self._log(f"Función de {self.animals[aid].meta['name']} actualizada ✨", "ok")

    def clear_report_fn(self, aid: str):
        if aid in self.animals:
            self.animals[aid]._report_fn = None

    def get_state(self) -> dict:
        return {
            "cycle":  self.cycle,
            "clima":  self.clima,
            "animals":{aid: a.to_dict() for aid, a in self.animals.items()},
            "events": list(self.events)[:20],
            "ts":     datetime.now(timezone.utc).isoformat(),
        }

    def get_karma_avg(self) -> float:
        karmas = [a.karma for a in self.animals.values()]
        return round(sum(karmas) / len(karmas), 3) if karmas else 0.0

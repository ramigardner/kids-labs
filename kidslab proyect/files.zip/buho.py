# 🦉 Función del Búho
# El Búho reporta cuántas estrellas ve según el clima.
# ¡Modificá esta función para que reporte bien!

def reportar_buho(clima):
    # El Búho siempre dice lo mismo... eso no está bien!
    # Cambiá el return para que devuelva 8 si llueve y 3 si hace sol.
    return 5


# ── Prueba rápida ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Con lluvia:", reportar_buho("🌧️ lluvia"))   # Debería ser 8
    print("Con sol:   ", reportar_buho("☀️ soleado"))  # Debería ser 3
    print("Con nubes: ", reportar_buho("🌤️ nublado"))  # Debería ser 3

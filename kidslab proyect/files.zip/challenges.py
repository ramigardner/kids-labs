"""
challenges.py — Gestor de desafíos de código Python para niños
Cada desafío presenta un problema del jardín, un fragmento de código editable
y una función de verificación automática.
"""
import ast
import sys
import traceback
from io import StringIO
from contextlib import redirect_stdout

# ── Desafíos ────────────────────────────────────────────────────────────────
CHALLENGES = [
    {
        "id":      "buho_clima",
        "animal":  "buho",
        "title":   "El Búho y la lluvia",
        "emoji":   "🦉🌧️",
        "story":   (
            "El Búho siempre reporta 5 estrellas sin importar el clima. "
            "¡Pero cuando llueve debería ver más, porque el cielo está despejado de pájaros! "
            "Cambiá la función para que reporte 8 cuando llueve y 3 cuando hace sol."
        ),
        "hint":    "Usá if/else con la palabra 'lluvia' en el clima.",
        "starter": (
            "def reportar_buho(clima):\n"
            "    # El Búho siempre dice lo mismo... eso no está bien!\n"
            "    return 5\n"
        ),
        "solution_hint": (
            "def reportar_buho(clima):\n"
            "    if 'lluvia' in clima:\n"
            "        return 8\n"
            "    else:\n"
            "        return 3\n"
        ),
        "tests": [
            {"input": "🌧️ lluvia",   "expected": 8,  "label": "Con lluvia"},
            {"input": "☀️ soleado",  "expected": 3,  "label": "Con sol"},
            {"input": "🌤️ nublado",  "expected": 3,  "label": "Con nubes"},
        ],
        "fn_name":   "reportar_buho",
        "animal_key": "buho",
    },
    {
        "id":      "zorro_latencia",
        "animal":  "zorro",
        "title":   "El Zorro lento",
        "emoji":   "🦊⚡",
        "story":   (
            "El Zorro tiene mucha latencia: ¡tarda 200ms en entregar mensajes! "
            "Para que su Karma mejore, la función tiene que devolver menos de 50. "
            "Cambiá el número que devuelve y observá cómo sube su Brillo."
        ),
        "hint":    "Simplemente cambiá el número que devuelve return. Tiene que ser menor a 50.",
        "starter": (
            "def calcular_latencia_zorro():\n"
            "    # Muy lento! El Karma del Zorro sufre.\n"
            "    return 200\n"
        ),
        "solution_hint": (
            "def calcular_latencia_zorro():\n"
            "    return 30  # Mucho mejor!\n"
        ),
        "tests": [
            {"input": None, "expected_max": 50, "label": "Latencia menor a 50ms", "mode": "max"},
            {"input": None, "expected_min": 1,  "label": "Latencia mayor a 0",    "mode": "min"},
        ],
        "fn_name":   "calcular_latencia_zorro",
        "animal_key": "zorro",
    },
    {
        "id":      "topo_perdida",
        "animal":  "topo",
        "title":   "El Topo y los paquetes perdidos",
        "emoji":   "🐾📦",
        "story":   (
            "El Topo pierde muchos paquetes de datos en su cueva. "
            "La función devuelve el porcentaje de pérdida. "
            "Si devuelve más de 20, su Karma cae mucho. "
            "Hacé que la función calcule bien: si hay humedad alta, la pérdida es 5; "
            "si hay humedad baja, la pérdida es 2."
        ),
        "hint":    "Usá if/else comparando el valor de humedad con un número.",
        "starter": (
            "def perdida_topo(humedad):\n"
            "    # Siempre pierde el 30%... terrible!\n"
            "    return 30\n"
        ),
        "solution_hint": (
            "def perdida_topo(humedad):\n"
            "    if humedad > 70:\n"
            "        return 5\n"
            "    else:\n"
            "        return 2\n"
        ),
        "tests": [
            {"input": 80,  "expected": 5,  "label": "Humedad alta (80)"},
            {"input": 30,  "expected": 2,  "label": "Humedad baja (30)"},
            {"input": 100, "expected": 5,  "label": "Humedad máxima (100)"},
        ],
        "fn_name":   "perdida_topo",
        "animal_key": "topo",
    },
    {
        "id":      "abeja_suma",
        "animal":  "abeja",
        "title":   "La Abeja contadora",
        "emoji":   "🐝🌸",
        "story":   (
            "La Abeja tiene que contar cuántas flores visitó. "
            "Recibe una lista de números (flores por zona) y tiene que devolver el total. "
            "Ahora mismo la función siempre devuelve 0. ¡Ayudá a la Abeja a sumar bien!"
        ),
        "hint":    "Usá sum() con la lista, o un bucle for que vaya sumando.",
        "starter": (
            "def contar_flores(zonas):\n"
            "    # La Abeja olvidó cómo sumar!\n"
            "    return 0\n"
        ),
        "solution_hint": (
            "def contar_flores(zonas):\n"
            "    return sum(zonas)\n"
        ),
        "tests": [
            {"input": [3, 5, 2],    "expected": 10, "label": "Tres zonas"},
            {"input": [10, 0, 7, 3], "expected": 20, "label": "Cuatro zonas"},
            {"input": [1],          "expected": 1,  "label": "Una zona sola"},
        ],
        "fn_name":   "contar_flores",
        "animal_key": "abeja",
    },
    {
        "id":      "karma_formula",
        "animal":  "buho",
        "title":   "La fórmula del Karma",
        "emoji":   "🧮✨",
        "story":   (
            "¡Hora de aprender la fórmula del Jardín! "
            "El Karma se calcula con 5 ingredientes. "
            "Completá la función usando los pesos correctos: "
            "memoria×0.30 + ciclos×0.25 + anclaje×0.20 + eficiencia×0.15 + corrección×0.10"
        ),
        "hint":    "Multiplicá cada componente por su peso y sumá todo.",
        "starter": (
            "def calcular_karma(memoria, ciclos, anclaje, eficiencia, correccion):\n"
            "    # Completá la fórmula del Jardín!\n"
            "    karma = 0  # Cambia esto\n"
            "    return round(karma, 3)\n"
        ),
        "solution_hint": (
            "def calcular_karma(memoria, ciclos, anclaje, eficiencia, correccion):\n"
            "    karma = (memoria * 0.30 + ciclos * 0.25 +\n"
            "             anclaje * 0.20 + eficiencia * 0.15 + correccion * 0.10)\n"
            "    return round(karma, 3)\n"
        ),
        "tests": [
            {
                "input": (1.0, 1.0, 1.0, 1.0, 1.0),
                "expected": 1.0,
                "label": "Perfecto en todo",
                "multi": True,
            },
            {
                "input": (0.0, 0.0, 0.0, 0.0, 0.0),
                "expected": 0.0,
                "label": "Cero en todo",
                "multi": True,
            },
            {
                "input": (1.0, 0.0, 0.0, 0.0, 0.0),
                "expected": 0.3,
                "label": "Solo memoria perfecta",
                "multi": True,
            },
        ],
        "fn_name":   "calcular_karma",
        "animal_key": "buho",
    },
]

CHALLENGE_MAP = {c["id"]: c for c in CHALLENGES}

# ── Sandbox de ejecución ────────────────────────────────────────────────────
BLOCKED_BUILTINS = {"__import__", "open", "eval", "exec", "compile",
                    "globals", "locals", "vars", "dir", "getattr", "setattr",
                    "delattr", "input", "breakpoint"}

def _safe_exec(code: str, fn_name: str) -> tuple[object, str]:
    """Ejecuta código en un sandbox mínimo. Devuelve (función, error_str)."""
    # Validación sintáctica
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return None, f"Error de sintaxis en línea {e.lineno}: {e.msg}"

    # Detección de imports y llamadas peligrosas
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            return None, "No se permiten imports en el desafío."
        if isinstance(node, ast.Call):
            fn = node.func
            name = fn.id if isinstance(fn, ast.Name) else getattr(fn, "attr", "")
            if name in BLOCKED_BUILTINS:
                return None, f"No se puede usar '{name}' en el desafío."

    namespace = {"__builtins__": {
        "range": range, "len": len, "sum": sum, "min": min, "max": max,
        "abs": abs, "round": round, "int": int, "float": float, "str": str,
        "bool": bool, "list": list, "print": print, "isinstance": isinstance,
        "enumerate": enumerate, "zip": zip,
    }}
    buf = StringIO()
    try:
        with redirect_stdout(buf):
            exec(compile(tree, "<kids_lab>", "exec"), namespace)
    except Exception as e:
        return None, f"Error al ejecutar: {e}"

    fn = namespace.get(fn_name)
    if fn is None:
        return None, f"No encontré la función '{fn_name}'. ¿La escribiste bien?"
    return fn, ""


def run_challenge(challenge_id: str, code: str) -> dict:
    """
    Ejecuta el código del niño contra los tests del desafío.
    Devuelve resultados detallados.
    """
    ch = CHALLENGE_MAP.get(challenge_id)
    if not ch:
        return {"ok": False, "error": "Desafío no encontrado."}

    fn, err = _safe_exec(code, ch["fn_name"])
    if err:
        return {"ok": False, "error": err, "tests": []}

    results   = []
    all_pass  = True
    stars_won = 0

    for test in ch["tests"]:
        mode = test.get("mode")
        try:
            if ch["fn_name"] == "calcular_karma" and test.get("multi"):
                got = fn(*test["input"])
            elif test["input"] is None:
                got = fn()
            elif isinstance(test["input"], list):
                got = fn(test["input"])
            else:
                got = fn(test["input"])
            got = float(got) if not isinstance(got, bool) else got
        except Exception as e:
            results.append({
                "label": test["label"], "passed": False,
                "got": "Error", "expected": test.get("expected", "?"),
                "msg": str(e),
            })
            all_pass = False
            continue

        if mode == "max":
            passed = got <= test["expected_max"]
            exp_str = f"≤ {test['expected_max']}"
        elif mode == "min":
            passed = got >= test["expected_min"]
            exp_str = f"≥ {test['expected_min']}"
        else:
            passed = abs(got - float(test["expected"])) < 0.001
            exp_str = str(test["expected"])

        if passed:
            stars_won += 1

        results.append({
            "label":   test["label"],
            "passed":  passed,
            "got":     round(got, 3) if isinstance(got, float) else got,
            "expected": exp_str,
            "msg":     "¡Correcto! 🌟" if passed else f"Esperaba {exp_str}, recibí {got}",
        })
        all_pass = all_pass and passed

    return {
        "ok":           all_pass,
        "tests":        results,
        "stars_won":    stars_won,
        "total_tests":  len(ch["tests"]),
        "animal_key":   ch["animal_key"],
        "fn_name":      ch["fn_name"],
        "fn_object":    fn if all_pass else None,
        "message": (
            "¡Perfecto! El jardín mejoró gracias a vos 🌱✨" if all_pass
            else "Casi! Revisá los tests que fallaron y probá de nuevo."
        ),
    }


def get_challenges_list() -> list[dict]:
    return [
        {
            "id":      c["id"],
            "title":   c["title"],
            "emoji":   c["emoji"],
            "animal":  c["animal"],
            "story":   c["story"],
            "hint":    c["hint"],
            "starter": c["starter"],
            "fn_name": c["fn_name"],
        }
        for c in CHALLENGES
    ]

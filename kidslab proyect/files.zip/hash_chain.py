"""
hash_chain.py — Cadena de Sellos del Jardín
Versión educativa de LocIVault: cada bloque tiene un "sello" visible (hash corto)
y un emoji-firma para que los niños puedan verificar la cadena visualmente.
"""
import hashlib
import json
import random
from datetime import datetime, timezone

# Emojis de sello: representan el "garabato único" de cada bloque
SEAL_EMOJIS = ["🌞", "🌙", "⭐", "🍀", "🌸", "🦋", "🌈", "🍄", "🎯", "🔮",
               "🌊", "🔥", "❄️", "🌿", "💎", "🎪", "🧩", "🎨", "🚀", "🌺"]


def _compute_hash(index: int, data: dict, prev_hash: str) -> str:
    payload = json.dumps(
        {"index": index, "data": data, "prev": prev_hash},
        sort_keys=True, ensure_ascii=False
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def _short_seal(full_hash: str) -> str:
    """Hash corto de 6 chars para mostrar a los niños."""
    return full_hash[:6].upper()


class HashChain:
    def __init__(self):
        self.blocks: list[dict] = []
        self._tampered_index: int | None = None

    def add_block(self, animal_id: str, animal_name: str, animal_emoji: str,
                  data: dict) -> dict:
        prev_hash = self.blocks[-1]["full_hash"] if self.blocks else "0" * 64
        index     = len(self.blocks)
        full_hash = _compute_hash(index, data, prev_hash)

        block = {
            "index":        index,
            "animal_id":    animal_id,
            "animal_name":  animal_name,
            "animal_emoji": animal_emoji,
            "data":         data,
            "prev_hash":    prev_hash,
            "full_hash":    full_hash,
            "prev_seal":    _short_seal(prev_hash) if prev_hash != "0" * 64 else "GÉNESIS",
            "seal":         _short_seal(full_hash),
            "seal_emoji":   SEAL_EMOJIS[index % len(SEAL_EMOJIS)],
            "ts":           datetime.now().strftime("%H:%M:%S"),
            "tampered":     False,
            "valid":        True,
        }
        self.blocks.append(block)
        return block

    def verify_chain(self) -> list[dict]:
        """Re-verifica toda la cadena y marca bloques rotos."""
        results = []
        for i, block in enumerate(self.blocks):
            prev_hash = self.blocks[i - 1]["full_hash"] if i > 0 else "0" * 64
            expected  = _compute_hash(i, block["data"], prev_hash)
            is_valid  = (block["full_hash"] == expected) and (block["prev_hash"] == prev_hash)
            block["valid"] = is_valid
            results.append({
                "index":   i,
                "valid":   is_valid,
                "seal":    block["seal"],
                "animal":  block["animal_emoji"],
            })
        return results

    def tamper_block(self, index: int) -> bool:
        """
        Modifica silenciosamente un bloque (simula a alguien intentando hacer trampa).
        El hash queda desincronizado con los datos.
        """
        if 0 <= index < len(self.blocks):
            b = self.blocks[index]
            # Cambia el dato pero NO recalcula el hash → cadena rota
            b["data"] = {**b["data"], "valor": round(random.uniform(50, 99), 1)}
            b["tampered"] = True
            b["valid"]    = False
            self._tampered_index = index
            return True
        return False

    def restore_block(self, index: int) -> bool:
        """Restaura un bloque manipulado recalculando su hash."""
        if 0 <= index < len(self.blocks):
            b         = self.blocks[index]
            prev_hash = self.blocks[index - 1]["full_hash"] if index > 0 else "0" * 64
            new_hash  = _compute_hash(index, b["data"], prev_hash)
            b["full_hash"] = new_hash
            b["seal"]      = _short_seal(new_hash)
            b["tampered"]  = False
            b["valid"]     = True
            self._tampered_index = None
            return True
        return False

    def get_last_n(self, n: int = 12) -> list[dict]:
        return self.blocks[-n:] if self.blocks else []

    def get_integrity(self) -> dict:
        if not self.blocks:
            return {"ok": True, "total": 0, "broken": []}
        results  = self.verify_chain()
        broken   = [r["index"] for r in results if not r["valid"]]
        return {
            "ok":     len(broken) == 0,
            "total":  len(self.blocks),
            "broken": broken,
            "tip":    self.blocks[-1]["seal"] if self.blocks else None,
        }

    def to_list(self) -> list[dict]:
        """Para serializar a JSON (sin full_hash para mantener el misterio)."""
        out = []
        for b in self.blocks[-15:]:
            out.append({
                "index":        b["index"],
                "animal_id":    b["animal_id"],
                "animal_name":  b["animal_name"],
                "animal_emoji": b["animal_emoji"],
                "seal":         b["seal"],
                "prev_seal":    b["prev_seal"],
                "seal_emoji":   b["seal_emoji"],
                "ts":           b["ts"],
                "valor":        b["data"].get("valor"),
                "clima":        b["data"].get("clima", ""),
                "karma":        b["data"].get("karma"),
                "tampered":     b["tampered"],
                "valid":        b["valid"],
            })
        return out

# 🌿 ASPR Kids Lab

Entorno educativo interactivo basado en el [ASPR Oracle Node](https://github.com/ramigardner/aspr-gardener).
Enseña pensamiento computacional, lógica y programación Python mediante un jardín de animales científicos.

---

## ¿Qué aprenden los niños?

| Concepto técnico real        | Cómo se llama en el jardín            |
|------------------------------|---------------------------------------|
| Karma / KPI de confianza     | **Brillo** ⭐ (0–100%)                |
| Hash chain (blockchain)      | **Cadena de sellos** 🔗               |
| Latencia de red              | **Velocidad** del mensajero           |
| Packet loss                  | **Paquetes perdidos** en la cueva     |
| Función Python               | **Comportamiento** de cada animal     |
| Sandbox de ejecución segura  | Editor web con verificación automática|
| Detección de manipulación    | Mini-juego **Detective de cadenas**   |

---

## Instalación

```bash
# 1. Clonar / copiar la carpeta aspr_kids_lab/
cd aspr_kids_lab

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Arrancar el servidor
python app.py

# 4. Abrir el browser
# → http://localhost:5050
```

---

## Estructura

```
aspr_kids_lab/
├── app.py              # Servidor Flask + SocketIO (tiempo real)
├── garden_state.py     # Lógica del jardín: animales, karma, eventos
├── hash_chain.py       # Cadena de bloques educativa con emojis
├── challenges.py       # 5 desafíos Python con sandbox seguro
├── requirements.txt
├── templates/
│   └── index.html      # Dashboard: 3 pestañas interactivas
└── challenge_files/    # Funciones editables (también editables en el browser)
    ├── buho.py
    ├── zorro.py
    └── topo.py
```

---

## Pestañas del dashboard

### 🌱 Jardín en vivo
- 4 animales con barras de Brillo (Karma) en tiempo real
- Controles por animal: hacer ruido 📢, desconectar 🔴, ajustar velocidad
- Log de eventos y vista de los últimos sellos de la cadena

### 🔬 Laboratorio de código
5 desafíos Python ordenados por dificultad:
1. **El Búho y la lluvia** — `if/else` básico
2. **El Zorro lento** — cambiar un valor de retorno
3. **El Topo y los paquetes perdidos** — `if/else` con comparación numérica
4. **La Abeja contadora** — `sum()` o bucle `for`
5. **La fórmula del Karma** — operaciones aritméticas con pesos

Cada desafío tiene: historia, pista, tests automáticos, y verificación que aplica la función al jardín en vivo.

### 🕵️ Detective de cadenas
- Visualización de todos los bloques de la cadena con su sello emoji
- Botón "Simular trampa" → modifica silenciosamente un bloque
- Botón "Verificar" → detecta y resalta los bloques rotos en rojo
- Los niños aprenden visualmente qué es un hash inmutable

---

## Endpoints REST (compatibles con Oracle Node real)

| Endpoint            | Descripción                        |
|---------------------|------------------------------------|
| `GET /api/state`    | Estado completo del jardín         |
| `GET /verify?animal=buho` | Karma de un animal específico |
| `GET /chain/latest` | Último bloque de la cadena         |
| `GET /chain/verify` | Verificación de integridad         |
| `GET /api/challenges` | Lista de desafíos disponibles    |

---

## SocketIO events

| Evento emitido      | Dirección | Descripción                         |
|---------------------|-----------|-------------------------------------|
| `garden_update`     | server→client | Estado completo en tiempo real  |
| `action`            | client→server | Controlar animales (noise/offline/latency/filter) |
| `run_challenge`     | client→server | Ejecutar código Python del niño |
| `challenge_result`  | server→client | Resultados de tests             |
| `tamper_chain`      | client→server | Simular manipulación de bloque  |
| `verify_chain`      | client→server | Verificar integridad            |
| `chain_verified`    | server→client | Resultado de verificación       |

---

## Seguridad del sandbox

El código que escriben los niños se ejecuta en un sandbox que:
- Bloquea `import`, `open`, `eval`, `exec` y otras funciones peligrosas
- Valida la sintaxis antes de ejecutar
- Limita los builtins disponibles a operaciones matemáticas seguras
- Captura errores y los muestra de forma amigable

---

## Créditos

Basado en el protocolo **ASPR (Adaptive Structural Pruning & Reporting)** de [Ramiro Guevara](https://github.com/ramigardner/aspr-gardener).

> "En el Jardín de Karma, no gana el que habla más fuerte.
>  Gana el que recuerda bien lo que pasó ayer y mira por la ventana antes de hablar."

MIT License · moteroenchilado@gmail.com

# 🦊 Función del Zorro
# El Zorro es el mensajero del jardín.
# Su latencia (tiempo de entrega) afecta su Karma.
# ¡Reducí la latencia para mejorar su Brillo!

def calcular_latencia_zorro():
    # Muy lento! El Karma del Zorro sufre si esto es mayor a 50.
    # Cambiá el número que devuelve.
    return 200


# ── Prueba rápida ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    lat = calcular_latencia_zorro()
    print(f"Latencia: {lat}ms")
    if lat < 50:
        print("✅ ¡Excelente! El Zorro es rápido ahora.")
    elif lat < 100:
        print("⚠️ Regular. Puede mejorar más.")
    else:
        print("❌ Muy lento. El Karma del Zorro baja.")

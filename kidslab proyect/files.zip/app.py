#!/usr/bin/env python3
"""
app.py — ASPR Kids Lab · Servidor principal
Combina Flask + SocketIO para el dashboard educativo en tiempo real.

Uso:
    pip install -r requirements.txt
    python app.py
    → http://localhost:5050
"""
import eventlet
eventlet.monkey_patch()

from flask import Flask, jsonify, request, render_template
from flask_socketio import SocketIO, emit
from flask_cors import CORS

from garden_state import GardenState
from hash_chain   import HashChain
from challenges   import run_challenge, get_challenges_list

import threading
import time

# ── App ──────────────────────────────────────────────────────────────────────
app    = Flask(__name__)
CORS(app)
app.config["SECRET_KEY"] = "aspr-kids-lab-2025"
sio    = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

garden = GardenState()
chain  = HashChain()

# Poblar cadena con los reportes iniciales del jardín
for aid, animal in garden.animals.items():
    for report in reversed(list(animal.reports)):
        chain.add_block(aid, animal.meta["name"], animal.meta["emoji"], report)

# ── Background tick ──────────────────────────────────────────────────────────
def background_tick():
    while True:
        eventlet.sleep(4)
        reports = garden.force_tick()
        if reports:
            for aid, report in reports.items():
                a = garden.animals[aid]
                chain.add_block(aid, a.meta["name"], a.meta["emoji"], report)
        state = garden.get_state()
        state["chain"]     = chain.to_list()
        state["integrity"] = chain.get_integrity()
        sio.emit("garden_update", state)

sio.start_background_task(background_tick)

# ── HTTP REST (misma interfaz que Oracle Node real) ───────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/state")
def api_state():
    state = garden.get_state()
    state["chain"]     = chain.to_list()
    state["integrity"] = chain.get_integrity()
    return jsonify(state)

@app.route("/verify")
def verify():
    """Endpoint compatible con Oracle Node real."""
    aid = request.args.get("animal", request.args.get("ip", "buho"))
    a   = garden.animals.get(aid)
    if not a:
        return jsonify({"found": False, "message": "Animal no encontrado"}), 404
    return jsonify({
        "found":        True,
        "verified_by":  "ASPR Kids Lab",
        "animal":       a.meta["name"],
        "karma":        a.karma,
        "components":   a.components,
        "online":       a.online,
        "latency_ms":   a.latency,
        "stars":        a.stars,
    })

@app.route("/chain/latest")
def chain_latest():
    blocks = chain.get_last_n(1)
    if not blocks:
        return jsonify({"error": "chain_empty"}), 404
    b = blocks[0]
    return jsonify({
        "block_index":  b["index"],
        "seal":         b["seal"],
        "seal_emoji":   b["seal_emoji"],
        "prev_seal":    b["prev_seal"],
        "animal":       b["animal_name"],
        "ts":           b["ts"],
        "total_blocks": len(chain.blocks),
    })

@app.route("/chain/verify")
def chain_verify():
    results = chain.verify_chain()
    broken  = [r for r in results if not r["valid"]]
    return jsonify({
        "integrity_ok": len(broken) == 0,
        "total_blocks": len(chain.blocks),
        "broken":       broken,
    })

@app.route("/api/challenges")
def api_challenges():
    return jsonify(get_challenges_list())

# ── SocketIO events ──────────────────────────────────────────────────────────
@sio.on("connect")
def on_connect():
    state = garden.get_state()
    state["chain"]     = chain.to_list()
    state["integrity"] = chain.get_integrity()
    emit("garden_update", state)

@sio.on("action")
def on_action(data):
    """
    Acciones desde el dashboard:
      { "type": "noise",   "aid": "buho",  "value": true }
      { "type": "offline", "aid": "topo",  "value": true }
      { "type": "latency", "aid": "zorro", "value": 150  }
      { "type": "filter",  "aid": "buho"               }
    """
    action = data.get("type")
    aid    = data.get("aid")

    if action == "noise":
        garden.set_noise(aid, bool(data.get("value", True)))
    elif action == "offline":
        garden.set_online(aid, not bool(data.get("value", True)))
    elif action == "latency":
        garden.set_latency(aid, float(data.get("value", 50)))
    elif action == "filter":
        garden.set_noise(aid, False)
        garden.set_online(aid, True)
        garden.animals[aid].latency = 30
        garden._log(f"{garden.animals[aid].meta['name']} filtrado y restaurado 🌿", "ok")

    # Emitir nuevo estado inmediatamente
    reports = garden.force_tick()
    for a_id, report in reports.items():
        a = garden.animals[a_id]
        chain.add_block(a_id, a.meta["name"], a.meta["emoji"], report)

    state = garden.get_state()
    state["chain"]     = chain.to_list()
    state["integrity"] = chain.get_integrity()
    emit("garden_update", state, broadcast=True)

@sio.on("run_challenge")
def on_run_challenge(data):
    """
    Ejecuta el código de un desafío y devuelve resultados.
      { "challenge_id": "buho_clima", "code": "def reportar_buho(clima):\n    ..." }
    """
    ch_id  = data.get("challenge_id", "")
    code   = data.get("code", "")
    result = run_challenge(ch_id, code)

    # Si pasó todos los tests, aplicar la función al animal
    if result["ok"] and result.get("fn_object"):
        aid = result["animal_key"]
        garden.set_report_fn(aid, result["fn_object"])
        reports = garden.force_tick()
        for a_id, report in reports.items():
            a = garden.animals[a_id]
            chain.add_block(a_id, a.meta["name"], a.meta["emoji"], report)
        state = garden.get_state()
        state["chain"]     = chain.to_list()
        state["integrity"] = chain.get_integrity()
        emit("garden_update", state, broadcast=True)

    # No serializar el fn_object
    result.pop("fn_object", None)
    emit("challenge_result", result)

@sio.on("tamper_chain")
def on_tamper(data):
    """Simula manipulación de un bloque para el mini-juego detective."""
    index = int(data.get("index", 3))
    ok    = chain.tamper_block(index)
    emit("chain_tampered", {
        "ok":    ok,
        "index": index,
        "chain": chain.to_list(),
        "integrity": chain.get_integrity(),
    }, broadcast=True)

@sio.on("verify_chain")
def on_verify_chain():
    results = chain.verify_chain()
    emit("chain_verified", {
        "results":   results,
        "integrity": chain.get_integrity(),
        "chain":     chain.to_list(),
    }, broadcast=True)

@sio.on("reset_chain")
def on_reset_chain():
    for b in chain.blocks:
        if b["tampered"]:
            chain.restore_block(b["index"])
    emit("chain_verified", {
        "results":   chain.verify_chain(),
        "integrity": chain.get_integrity(),
        "chain":     chain.to_list(),
    }, broadcast=True)

if __name__ == "__main__":
    print("🌿 ASPR Kids Lab arrancando...")
    print("   → http://localhost:5050")
    sio.run(app, host="0.0.0.0", port=5050, debug=False)

"""ASPR Oracle Lab v2 — Lanzador"""
import subprocess, sys, os, time

BASE = os.path.dirname(__file__)

def check():
    missing = []
    for pkg in ["pygame", "numpy"]:
        try: __import__(pkg)
        except ImportError: missing.append(pkg)
    if missing:
        print(f"[!] Instalando: {missing}")
        subprocess.check_call([sys.executable,"-m","pip","install"]+missing)

def server(): subprocess.Popen([sys.executable, os.path.join(BASE,"server.py")])
def client(): subprocess.Popen([sys.executable, os.path.join(BASE,"client.py")])

if __name__ == "__main__":
    check()
    mode = sys.argv[1] if len(sys.argv)>1 else "client"
    if mode == "server":
        server()
        print("Servidor corriendo en :9999  (Ctrl+C para detener)")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt: pass
    elif mode == "both":
        server(); time.sleep(1.2); client()
        print("Servidor + cliente iniciados")
    else:
        client()

"""
ASPR Oracle Lab — Motor de Sonido 8-bit
Síntesis de onda cuadrada pura estilo Commodore 64 SID chip.
Sin archivos externos — todo generado matemáticamente.
"""

import numpy as np
import pygame
import threading

# Frecuencias de notas (Hz)
NOTES = {
    "C3": 130.81, "D3": 146.83, "E3": 164.81, "F3": 174.61,
    "G3": 196.00, "A3": 220.00, "B3": 246.94,
    "C4": 261.63, "D4": 293.66, "E4": 329.63, "F4": 349.23,
    "G4": 392.00, "A4": 440.00, "B4": 493.88,
    "C5": 523.25, "D5": 587.33, "E5": 659.25, "F5": 698.46,
    "G5": 783.99, "A5": 880.00,
    "REST": 0,
}

SAMPLE_RATE = 22050
CHANNELS = 1

# Jingles definidos como lista de (nota, duración_ms)
JINGLE_WIN = [
    ("E4", 100), ("E4", 100), ("REST", 50), ("E4", 100),
    ("REST", 50), ("C4", 100), ("E4", 150), ("G4", 300),
    ("REST", 150), ("G3", 300),
]

JINGLE_PIECE = [
    ("C5", 60), ("E5", 60), ("G5", 100),
]

JINGLE_ERROR = [
    ("A3", 80), ("G3", 80), ("F3", 120),
]

JINGLE_DOOR = [
    ("C4", 80), ("E4", 80), ("G4", 80), ("C5", 80),
    ("E5", 80), ("G5", 80), ("C5", 200),
]

JINGLE_PET = [
    ("G5", 60), ("A5", 60), ("G5", 60), ("E5", 60),
    ("C5", 60), ("D5", 60), ("E5", 200),
]

JINGLE_LEVEL_START = [
    ("C4", 100), ("G4", 100), ("E5", 100), ("C5", 200),
]


def _square_wave(freq: float, duration_ms: int, volume: float = 0.3, duty: float = 0.5) -> np.ndarray:
    """Genera onda cuadrada estilo SID chip."""
    n_samples = int(SAMPLE_RATE * duration_ms / 1000)
    if freq == 0 or n_samples == 0:
        return np.zeros(n_samples, dtype=np.int16)
    t = np.linspace(0, duration_ms / 1000, n_samples, endpoint=False)
    # Onda cuadrada con duty cycle
    wave = np.where((t * freq) % 1.0 < duty, 1.0, -1.0)
    # Envelope: fade out suave para evitar clicks
    fade = np.ones(n_samples)
    fade_len = min(int(n_samples * 0.15), 200)
    if fade_len > 0:
        fade[-fade_len:] = np.linspace(1, 0, fade_len)
        fade[:int(fade_len*0.3)] = np.linspace(0, 1, int(fade_len*0.3))
    wave = wave * fade * volume * 32767
    return wave.astype(np.int16)


def _render_jingle(jingle: list) -> np.ndarray:
    """Convierte lista de (nota, ms) a array de audio."""
    parts = []
    for note, dur in jingle:
        freq = NOTES.get(note, 0)
        parts.append(_square_wave(freq, dur))
    return np.concatenate(parts) if parts else np.zeros(100, dtype=np.int16)


class SoundEngine:
    def __init__(self):
        self.enabled = False
        self._lock = threading.Lock()
        self._channels = {}

    def init(self):
        try:
            pygame.mixer.pre_init(SAMPLE_RATE, -16, CHANNELS, 512)
            pygame.mixer.init()
            pygame.mixer.set_num_channels(8)
            self.enabled = True
            # Pre-renderizar todos los jingles
            self._sounds = {
                "win":         self._make_sound(JINGLE_WIN),
                "piece":       self._make_sound(JINGLE_PIECE),
                "error":       self._make_sound(JINGLE_ERROR),
                "door":        self._make_sound(JINGLE_DOOR),
                "pet":         self._make_sound(JINGLE_PET),
                "level_start": self._make_sound(JINGLE_LEVEL_START),
            }
        except Exception as e:
            print(f"[Sound] Desactivado: {e}")
            self.enabled = False

    def _make_sound(self, jingle: list) -> pygame.sndarray.make_sound:
        arr = _render_jingle(jingle)
        # pygame necesita array 2D para mono en algunas versiones
        if CHANNELS == 1:
            try:
                arr2d = np.column_stack([arr, arr])
                return pygame.sndarray.make_sound(arr2d)
            except Exception:
                return pygame.sndarray.make_sound(arr)
        return pygame.sndarray.make_sound(arr)

    def play(self, name: str):
        if not self.enabled:
            return
        sound = self._sounds.get(name)
        if sound:
            try:
                sound.play()
            except Exception:
                pass

    def beep(self, freq: float = 440, duration_ms: int = 100):
        """Beep personalizado."""
        if not self.enabled:
            return
        try:
            arr = _square_wave(freq, duration_ms)
            arr2d = np.column_stack([arr, arr])
            s = pygame.sndarray.make_sound(arr2d)
            s.play()
        except Exception:
            pass


# Instancia global
sfx = SoundEngine()

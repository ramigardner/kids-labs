# ASPR Oracle Lab v2 🐢
**Kids Lab — Puerta de entrada a la informática real**
Apéndice del ASPR Oracle Node v2.0 · Python + Pygame · PvP LAN/Online

---

## ¿Qué es?

Un juego de red 1v1 (Hacker vs Nerd) donde los chicos aprenden
programación dibujando figuras con comandos Logo estilo Commodore 64.
La tortuga dibuja la figura → la puerta se abre → avanzás de nivel.

---

## Instalación

```bash
pip install pygame numpy
```

---

## Cómo jugar

```bash
# En la PC servidor:
python server.py

# En cada cliente:
python client.py
```

En modo LAN el segundo jugador escribe la IP del servidor.
Con Tailscale: usá la IP `100.x.x.x:9999`.

**Todo en una PC (debug):**
```bash
python launch.py both
# Luego abrí otro cliente: python client.py
```

---

## Layout de pantalla

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  Avatar camina → llega a la terminal → Tortuga Logo dibuja     │  60%
│  la figura paso a paso con cada comando correcto               │
│  [Rival visible en el otro lado con su propio progreso]        │
│                                                                 │
├─────────────────┬───────────────────────────────────────────────┤
│  STATS          │  CONSOLA LOGO                                 │
│  • Power        │  NIVEL 1: LA LLAVE                            │  40%
│  • Karma        │  >> 1. ADELANTE 4  ← paso actual             │
│  • Hambre pet   │     2. DERECHA 90                             │
│  • Timer        │     3. ADELANTE 2  ...                        │
│  • Wins         │  READY. █  (escribís acá)                     │
└─────────────────┴───────────────────────────────────────────────┘
```

---

## Niveles y figuras

| # | Figura | Comandos | Concepto |
|---|--------|----------|----------|
| 1 | 🔑 La Llave | ADELANTE, DERECHA, IZQUIERDA | Comandos básicos |
| 2 | ⬜ El Cuadrado | ADELANTE, DERECHA | Patrones repetidos |
| 3 | 🛡 El Escudo | ADELANTE, DERECHA, IZQUIERDA | Ángulos distintos |
| 4 | ⭐ La Estrella | ADELANTE, DERECHA (144°) | Matemática + código |

---

## Comandos Logo (en español)

```
ADELANTE 4     → la tortuga avanza 4 celdas dibujando
DERECHA 90     → gira 90 grados a la derecha
IZQUIERDA 90   → gira 90 grados a la izquierda
ATRAS 2        → retrocede 2 celdas
```

---

## Controles

| Tecla | Acción |
|-------|--------|
| Escribís directo | Tipear comando |
| Enter | Enviar comando |
| Backspace | Borrar |
| Ctrl+F | Alimentar mascota |
| Escape | Limpiar input |

---

## Mascotas

Se desbloquea al completar el **primer nivel**.
- **Hackers**: Daemon 👾, Glitch 🦠, Void 🕷️
- **Nerds**: Patchbot 🤖, Hashling 🔮, Cyphera 🦋

---

## Sonidos 8-bit

Todo generado matemáticamente con numpy (onda cuadrada pura).
Sin archivos de audio — 100% síntesis estilo chip SID del C64.

| Evento | Sonido |
|--------|--------|
| Comando correcto | Bip ascendente |
| Comando incorrecto | Bzzzt grave |
| Nivel completo | Jingle Mario-style |
| Puerta se abre | Fanfarria |
| Mascota aparece | Melodía 8-bit |

---

## Arquitectura

```
server.py   ← TCP asíncrono (asyncio), lógica de sesión y niveles
client.py   ← Pygame: animación, tortuga Logo, consola, red en thread
puzzle.py   ← Motor Logo: parser de comandos, figuras, tortuga
sound.py    ← Síntesis 8-bit con numpy: ondas cuadradas puras
launch.py   ← Helper de arranque
```

---

## Conexión con el Oracle Node

- La figura del **Escudo** representa el Oracle Node real
- El concepto de **karma** y **power** vienen de la fórmula ASPR:
  `K = Memory×0.30 + Cycles×0.25 + Anchoring×0.20 + ...`
- Puerto 9999 no pisa el nodo (7771)
- La IP pública del nodo puede usarse como servidor online

---

## Roadmap futuro

- [ ] Modo cooperativo (los dos construyen la misma figura)
- [ ] Niveles avanzados en inglés (FORWARD, RIGHT) — puente idiomático
- [ ] Editor de figuras para que los docentes creen sus propios niveles
- [ ] Integración con `/api/state` del Oracle Node como fuente de datos viva
- [ ] Leaderboard persistente via `registry.json`
- [ ] Sonidos distintos para cada nivel

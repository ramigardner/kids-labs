"""
ASPR Oracle Lab v2 — Servidor TCP
Maneja sesiones PvP: Hackers vs Nerds resolviendo puzzles Logo.
Puerto: 9999
"""

import asyncio
import json
import time
import random

from puzzle import LEVELS, check_command_matches_step

# ─── Sesión de juego ──────────────────────────────────────────────────────────

PETS = {
    "hacker": [
        {"name": "Daemon",  "emoji": "👾", "power": "Shadow Cloak"},
        {"name": "Glitch",  "emoji": "🦠", "power": "Virus Spread"},
        {"name": "Void",    "emoji": "🕷️", "power": "Web Trap"},
    ],
    "nerd": [
        {"name": "Patchbot","emoji": "🤖", "power": "Auto-Verify"},
        {"name": "Hashling","emoji": "🔮", "power": "Hash Shield"},
        {"name": "Cyphera", "emoji": "🦋", "power": "Cipher Wing"},
    ],
}


class PlayerState:
    def __init__(self, pid, name, role):
        self.pid = pid
        self.name = name
        self.role = role
        self.power = 50
        self.karma = 0
        self.wins = 0
        self.step_index = 0   # avance en el puzzle actual
        self.has_pet = False
        self.pet = random.choice(PETS.get(role, PETS["nerd"])).copy()
        self.pet["hunger"] = 100
        self.ready = False
        self.finished_level = False
        self.finish_time = None

    def to_dict(self):
        return {
            "pid": self.pid,
            "name": self.name,
            "role": self.role,
            "power": self.power,
            "karma": self.karma,
            "wins": self.wins,
            "step_index": self.step_index,
            "has_pet": self.has_pet,
            "pet": self.pet,
            "finished_level": self.finished_level,
        }


class GameSession:
    def __init__(self, sid):
        self.sid = sid
        self.players: dict[str, PlayerState] = {}
        self.level_index = 0
        self.started = False
        self.finished = False
        self.winner_pid = None
        self.timer_start = None
        self.TIME_LIMIT = 120  # segundos por nivel

    @property
    def current_level(self):
        if self.level_index < len(LEVELS):
            return LEVELS[self.level_index]
        return None

    def add_player(self, pid, name, role):
        self.players[pid] = PlayerState(pid, name, role)

    def time_remaining(self):
        if not self.timer_start:
            return self.TIME_LIMIT
        return max(0, self.TIME_LIMIT - (time.time() - self.timer_start))

    def start_level(self):
        self.timer_start = time.time()
        for p in self.players.values():
            p.step_index = 0
            p.finished_level = False
            p.finish_time = None

    def submit_step(self, pid: str, user_input: str) -> dict:
        player = self.players.get(pid)
        lv = self.current_level
        if not player or not lv:
            return {"ok": False, "msg": "Sin nivel activo"}

        if player.finished_level:
            return {"ok": False, "msg": "Ya terminaste este nivel"}

        steps = lv["pasos"]
        if player.step_index >= len(steps):
            return {"ok": False, "msg": "Ya completaste todos los pasos"}

        current_step = steps[player.step_index]
        valid_cmds = lv["comandos_validos"]

        ok, msg = check_command_matches_step(user_input, current_step, valid_cmds)
        if ok:
            player.step_index += 1
            player.karma += 5
            player.power = min(100, player.power + 3)
            if player.step_index >= len(steps):
                player.finished_level = True
                player.finish_time = time.time()
                player.wins += 1
                player.karma += 50
                if not player.has_pet:
                    player.has_pet = True
            return {
                "ok": True,
                "correct": True,
                "step": player.step_index,
                "total": len(steps),
                "msg": msg,
                "level_complete": player.finished_level,
            }
        else:
            player.power = max(0, player.power - 5)
            return {"ok": True, "correct": False, "msg": msg}

    def check_level_winner(self) -> str | None:
        """Retorna pid del ganador si alguien terminó el nivel."""
        for pid, p in self.players.items():
            if p.finished_level:
                return pid
        return None

    def advance_level(self):
        self.level_index += 1
        if self.level_index >= len(LEVELS):
            self.finished = True
            # Ganador por karma
            top = max(self.players.values(), key=lambda p: p.karma)
            self.winner_pid = top.pid
        else:
            self.start_level()

    def to_dict(self):
        lv = self.current_level
        return {
            "sid": self.sid,
            "level_index": self.level_index,
            "level": {
                "id": lv["id"],
                "titulo": lv["titulo"],
                "emoji_titulo": lv["emoji_titulo"],
                "descripcion": lv["descripcion"],
                "concepto": lv["concepto"],
                "total_pasos": len(lv["pasos"]),
                "comandos_validos": list(lv["comandos_validos"].keys()),
            } if lv else None,
            "started": self.started,
            "finished": self.finished,
            "winner_pid": self.winner_pid,
            "time_remaining": self.time_remaining(),
            "players": {pid: p.to_dict() for pid, p in self.players.items()},
        }


# ─── Servidor ─────────────────────────────────────────────────────────────────

sessions: dict[str, GameSession] = {}
clients: dict[str, asyncio.StreamWriter] = {}


async def broadcast(session: GameSession, msg: dict):
    data = json.dumps(msg) + "\n"
    for pid in session.players:
        w = clients.get(pid)
        if w:
            try:
                w.write(data.encode())
                await w.drain()
            except Exception:
                pass


async def send_to(pid: str, msg: dict):
    w = clients.get(pid)
    if w:
        try:
            w.write((json.dumps(msg) + "\n").encode())
            await w.drain()
        except Exception:
            pass


async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    pid = None
    session = None
    addr = writer.get_extra_info("peername")
    print(f"[SERVER] Conexión: {addr}")

    try:
        while True:
            raw = await reader.readline()
            if not raw:
                break
            try:
                msg = json.loads(raw.decode().strip())
            except Exception:
                continue

            action = msg.get("action")

            # ── JOIN ──────────────────────────────────────────────────────────
            if action == "join":
                pid = msg["pid"]
                sid = msg.get("sid", "default")
                clients[pid] = writer

                if sid not in sessions:
                    sessions[sid] = GameSession(sid)
                session = sessions[sid]

                if pid not in session.players:
                    session.add_player(pid, msg["name"], msg["role"])

                await broadcast(session, {
                    "type": "player_joined",
                    "pid": pid,
                    "state": session.to_dict(),
                })

                # Auto-start con 2 jugadores de roles distintos
                roles = {p.role for p in session.players.values()}
                if len(session.players) >= 2 and len(roles) >= 2 and not session.started:
                    session.started = True
                    session.start_level()
                    lv = session.current_level
                    # Enviar pasos a cada jugador
                    for p_pid in session.players:
                        await send_to(p_pid, {
                            "type": "level_start",
                            "state": session.to_dict(),
                            "pasos": lv["pasos"] if lv else [],
                        })
                    asyncio.create_task(timer_loop(session))

            # ── SUBMIT STEP ───────────────────────────────────────────────────
            elif action == "step" and session:
                user_input = msg.get("input", "")
                result = session.submit_step(pid, user_input)

                await broadcast(session, {
                    "type": "step_result",
                    "pid": pid,
                    "result": result,
                    "state": session.to_dict(),
                })

                # ¿Alguien terminó el nivel?
                winner_pid = session.check_level_winner()
                if winner_pid:
                    await asyncio.sleep(2.5)
                    session.advance_level()
                    if session.finished:
                        await broadcast(session, {
                            "type": "game_over",
                            "winner_pid": session.winner_pid,
                            "state": session.to_dict(),
                        })
                    else:
                        lv = session.current_level
                        for p_pid in session.players:
                            await send_to(p_pid, {
                                "type": "level_start",
                                "state": session.to_dict(),
                                "pasos": lv["pasos"] if lv else [],
                            })
                        asyncio.create_task(timer_loop(session))

            # ── FEED PET ──────────────────────────────────────────────────────
            elif action == "feed_pet" and session and pid:
                p = session.players.get(pid)
                if p and p.has_pet:
                    p.pet["hunger"] = min(100, p.pet["hunger"] + 20)
                    await broadcast(session, {"type": "pet_update", "pid": pid, "state": session.to_dict()})

            # ── PING ──────────────────────────────────────────────────────────
            elif action == "ping":
                writer.write((json.dumps({"type": "pong"}) + "\n").encode())
                await writer.drain()

    except Exception as e:
        print(f"[SERVER] Error {pid}: {e}")
    finally:
        if pid:
            clients.pop(pid, None)
        writer.close()
        print(f"[SERVER] Desconectado: {pid}")


async def timer_loop(session: GameSession):
    while session.started and not session.finished:
        tr = session.time_remaining()
        await broadcast(session, {"type": "tick", "time_remaining": tr, "state": session.to_dict()})
        if tr <= 0:
            # Tiempo agotado — penalizar y avanzar
            for p in session.players.values():
                p.power = max(0, p.power - 20)
            session.advance_level()
            if session.finished:
                await broadcast(session, {"type": "game_over", "winner_pid": session.winner_pid, "state": session.to_dict()})
            else:
                lv = session.current_level
                for p_pid in session.players:
                    await send_to(p_pid, {
                        "type": "level_start",
                        "state": session.to_dict(),
                        "pasos": lv["pasos"] if lv else [],
                    })
                asyncio.create_task(timer_loop(session))
            break
        await asyncio.sleep(1)


async def main():
    srv = await asyncio.start_server(handle_client, "0.0.0.0", 9999)
    print("[ASPR Oracle Lab v2] Servidor en 0.0.0.0:9999")
    async with srv:
        await srv.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())

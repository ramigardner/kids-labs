"""
ASPR Oracle Lab — Motor de Puzzle Logo
La tortuga dibuja figuras pixel a pixel con comandos en español.
Estética Commodore 64: grid visible, colores limitados, pixel puro.
"""

import pygame
import math
from dataclasses import dataclass, field
from typing import Optional

# ─── Paleta Commodore 64 ──────────────────────────────────────────────────────
C64 = {
    "black":      (0,    0,   0),
    "white":      (255, 255, 255),
    "red":        (136,  0,   0),
    "cyan":       (170, 255, 238),
    "purple":     (204,  68, 204),
    "green":      (0,  204,  85),
    "blue":       (0,    0,  170),
    "yellow":     (238, 238, 119),
    "orange":     (221, 136,  85),
    "brown":      (102,  68,   0),
    "lt_red":     (255, 119, 119),
    "dk_grey":    (51,   51,  51),
    "mid_grey":   (119, 119, 119),
    "lt_green":   (170, 255, 102),
    "lt_blue":    (0,  136, 255),
    "lt_grey":    (187, 187, 187),
}

# ─── Figuras de los niveles ───────────────────────────────────────────────────
# Cada figura es una secuencia de comandos Logo que la dibuja
# y una lista de "piezas" (segmentos) con su nombre y descripción

LEVELS = [
    {
        "id": 1,
        "titulo": "LA LLAVE",
        "emoji_titulo": "🔑",
        "descripcion": "Dibujá la llave para abrir la primera puerta",
        "color": C64["yellow"],
        "color_done": C64["lt_green"],
        "comandos_validos": {
            "ADELANTE": "fd",
            "DERECHA":  "rt",
            "IZQUIERDA":"lt",
            "ARRIBA":   "fd",
            "BAJAR":    "bk",
        },
        "pasos": [
            {"cmd": "ADELANTE 4", "desc": "Dibujá el mango de la llave",    "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Girá hacia la derecha",           "action": ("rt", 90)},
            {"cmd": "ADELANTE 2", "desc": "Dibujá el cuello",                "action": ("fd", 2)},
            {"cmd": "DERECHA 90", "desc": "Girá de nuevo",                   "action": ("rt", 90)},
            {"cmd": "ADELANTE 2", "desc": "Primer diente",                   "action": ("fd", 2)},
            {"cmd": "IZQUIERDA 90", "desc": "Girá a la izquierda",           "action": ("lt", 90)},
            {"cmd": "ADELANTE 1", "desc": "Segundo diente",                  "action": ("fd", 1)},
            {"cmd": "IZQUIERDA 90", "desc": "Último giro",                   "action": ("lt", 90)},
            {"cmd": "ADELANTE 1", "desc": "Cierra el diente",                "action": ("fd", 1)},
        ],
        "concepto": "Comandos básicos: ADELANTE, DERECHA, IZQUIERDA",
        "logro": "¡Aprendiste a dar órdenes!",
    },
    {
        "id": 2,
        "titulo": "EL CUADRADO",
        "emoji_titulo": "⬜",
        "descripcion": "Un cuadrado perfecto con 4 lados iguales",
        "color": C64["cyan"],
        "color_done": C64["lt_green"],
        "comandos_validos": {
            "ADELANTE": "fd",
            "DERECHA":  "rt",
        },
        "pasos": [
            {"cmd": "ADELANTE 4", "desc": "Primer lado",    "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Primer giro",    "action": ("rt", 90)},
            {"cmd": "ADELANTE 4", "desc": "Segundo lado",   "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Segundo giro",   "action": ("rt", 90)},
            {"cmd": "ADELANTE 4", "desc": "Tercer lado",    "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Tercer giro",    "action": ("rt", 90)},
            {"cmd": "ADELANTE 4", "desc": "Último lado",    "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "¡Cerraste el cuadrado!", "action": ("rt", 90)},
        ],
        "concepto": "Repetición: 4 veces lo mismo = una figura",
        "logro": "¡Entendiste los patrones!",
    },
    {
        "id": 3,
        "titulo": "EL ESCUDO",
        "emoji_titulo": "🛡",
        "descripcion": "El escudo del ASPR Oracle Node",
        "color": C64["lt_blue"],
        "color_done": C64["lt_green"],
        "comandos_validos": {
            "ADELANTE":   "fd",
            "DERECHA":    "rt",
            "IZQUIERDA":  "lt",
            "ATRAS":      "bk",
        },
        "pasos": [
            {"cmd": "ADELANTE 4", "desc": "Lado izquierdo",      "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Esquina superior",     "action": ("rt", 90)},
            {"cmd": "ADELANTE 4", "desc": "Lado superior",        "action": ("fd", 4)},
            {"cmd": "DERECHA 90", "desc": "Esquina derecha",      "action": ("rt", 90)},
            {"cmd": "ADELANTE 4", "desc": "Lado derecho",         "action": ("fd", 4)},
            {"cmd": "DERECHA 135","desc": "Ángulo del escudo",    "action": ("rt", 135)},
            {"cmd": "ADELANTE 3", "desc": "Diagonal derecha",     "action": ("fd", 3)},
            {"cmd": "DERECHA 90", "desc": "Punta del escudo",     "action": ("rt", 90)},
            {"cmd": "ADELANTE 3", "desc": "Diagonal izquierda",   "action": ("fd", 3)},
        ],
        "concepto": "Ángulos distintos: 90° y 135°",
        "logro": "¡Sos un Nerd del ASPR!",
    },
    {
        "id": 4,
        "titulo": "LA ESTRELLA",
        "emoji_titulo": "⭐",
        "descripcion": "Cinco puntas perfectas",
        "color": C64["yellow"],
        "color_done": C64["lt_green"],
        "comandos_validos": {
            "ADELANTE":  "fd",
            "DERECHA":   "rt",
        },
        "pasos": [
            {"cmd": "ADELANTE 5", "desc": "Punta 1",  "action": ("fd", 5)},
            {"cmd": "DERECHA 144","desc": "Giro estelar", "action": ("rt", 144)},
            {"cmd": "ADELANTE 5", "desc": "Punta 2",  "action": ("fd", 5)},
            {"cmd": "DERECHA 144","desc": "Giro estelar", "action": ("rt", 144)},
            {"cmd": "ADELANTE 5", "desc": "Punta 3",  "action": ("fd", 5)},
            {"cmd": "DERECHA 144","desc": "Giro estelar", "action": ("rt", 144)},
            {"cmd": "ADELANTE 5", "desc": "Punta 4",  "action": ("fd", 5)},
            {"cmd": "DERECHA 144","desc": "Giro estelar", "action": ("rt", 144)},
            {"cmd": "ADELANTE 5", "desc": "Punta 5 — ¡Cerrá la estrella!", "action": ("fd", 5)},
        ],
        "concepto": "360° / 5 puntas = 144° cada giro",
        "logro": "¡Matemática + código = magia!",
    },
]


# ─── Tortuga Logo ─────────────────────────────────────────────────────────────

CELL = 18  # píxeles por celda del grid

@dataclass
class Turtle:
    x: float = 0.0
    y: float = 0.0
    angle: float = 90.0   # 90 = mirando arriba
    trail: list = field(default_factory=list)  # [(x0,y0,x1,y1,color)]
    color: tuple = C64["yellow"]
    done_color: tuple = C64["lt_green"]
    step_index: int = 0
    total_steps: int = 0
    # Animación
    anim_x: float = 0.0
    anim_y: float = 0.0
    anim_target_x: float = 0.0
    anim_target_y: float = 0.0
    animating: bool = False
    anim_progress: float = 1.0
    error_shake: float = 0.0

    def reset(self, start_x: float, start_y: float, color, total_steps: int):
        self.x = start_x
        self.y = start_y
        self.anim_x = start_x
        self.anim_y = start_y
        self.anim_target_x = start_x
        self.anim_target_y = start_y
        self.angle = 90.0
        self.trail = []
        self.color = color
        self.step_index = 0
        self.total_steps = total_steps
        self.animating = False
        self.anim_progress = 1.0
        self.error_shake = 0.0

    def execute(self, action: tuple) -> bool:
        """Ejecuta acción (cmd, valor). Retorna True si OK."""
        cmd, val = action
        if cmd == "fd":
            rad = math.radians(self.angle)
            nx = self.x + math.cos(rad) * val
            ny = self.y - math.sin(rad) * val
            self.trail.append((self.x, self.y, nx, ny, self.color))
            self.anim_target_x = nx
            self.anim_target_y = ny
            self.anim_progress = 0.0
            self.animating = True
            self.x = nx
            self.y = ny
            self.step_index += 1
            return True
        elif cmd == "bk":
            rad = math.radians(self.angle)
            nx = self.x - math.cos(rad) * val
            ny = self.y + math.sin(rad) * val
            self.trail.append((self.x, self.y, nx, ny, self.color))
            self.anim_target_x = nx
            self.anim_target_y = ny
            self.anim_progress = 0.0
            self.animating = True
            self.x = nx
            self.y = ny
            self.step_index += 1
            return True
        elif cmd == "rt":
            self.angle -= val
            self.step_index += 1
            return True
        elif cmd == "lt":
            self.angle += val
            self.step_index += 1
            return True
        return False

    def shake_error(self):
        self.error_shake = 1.0

    def update(self, dt: float):
        if self.animating:
            self.anim_progress = min(1.0, self.anim_progress + dt * 5)
            self.anim_x = self.anim_x + (self.anim_target_x - self.anim_x) * min(1, dt * 10)
            self.anim_y = self.anim_y + (self.anim_target_y - self.anim_y) * min(1, dt * 10)
            if self.anim_progress >= 1.0:
                self.animating = False
                self.anim_x = self.anim_target_x
                self.anim_y = self.anim_target_y
        if self.error_shake > 0:
            self.error_shake = max(0, self.error_shake - dt * 4)

    def is_complete(self) -> bool:
        return self.step_index >= self.total_steps

    def draw(self, surf: pygame.Surface, origin_x: int, origin_y: int):
        """Dibuja el trail y la tortuga sobre el canvas."""
        # Trail (líneas dibujadas)
        completion = self.step_index / max(self.total_steps, 1)
        trail_color = self.done_color if completion >= 1.0 else self.color

        for seg in self.trail:
            x0, y0, x1, y1, col = seg
            px0 = int(origin_x + x0 * CELL)
            py0 = int(origin_y + y0 * CELL)
            px1 = int(origin_x + x1 * CELL)
            py1 = int(origin_y + y1 * CELL)
            # Glow
            for thickness in [5, 3, 2]:
                alpha_col = tuple(min(255, int(c * 0.4)) for c in trail_color)
                pygame.draw.line(surf, alpha_col, (px0, py0), (px1, py1), thickness)
            pygame.draw.line(surf, trail_color, (px0, py0), (px1, py1), 2)

        # Tortuga (cursor)
        shake_x = int(self.error_shake * 6 * math.sin(self.error_shake * 30)) if self.error_shake > 0 else 0
        tx = int(origin_x + self.anim_x * CELL) + shake_x
        ty = int(origin_y + self.anim_y * CELL)

        # Cuerpo pixelado de la tortuga (5x5 pixels)
        tort_color = C64["green"] if not self.error_shake else C64["red"]
        # Caparazón
        pygame.draw.rect(surf, tort_color,    (tx - 6, ty - 4, 12, 8))
        # Cabeza en dirección del ángulo
        rad = math.radians(self.angle)
        hx = int(tx + math.cos(rad) * 8)
        hy = int(ty - math.sin(rad) * 8)
        pygame.draw.rect(surf, C64["lt_green"], (hx - 3, hy - 3, 6, 6))
        # Ojos
        pygame.draw.rect(surf, C64["black"],   (tx - 3, ty - 2, 2, 2))
        pygame.draw.rect(surf, C64["black"],   (tx + 1, ty - 2, 2, 2))
        # Borde pixelado
        pygame.draw.rect(surf, C64["white"],   (tx - 6, ty - 4, 12, 8), 1)

        # Flecha de dirección
        pygame.draw.line(surf, C64["white"],
                         (tx, ty),
                         (int(tx + math.cos(rad) * 12), int(ty - math.sin(rad) * 12)), 1)


# ─── Parser de comandos en español ───────────────────────────────────────────

def parse_command(text: str, valid_cmds: dict) -> Optional[tuple]:
    """
    Parsea texto del usuario y retorna (action_tuple, step_index) o None.
    Ejemplo: "ADELANTE 4" → ("fd", 4)
    """
    text = text.strip().upper()
    parts = text.split()
    if not parts:
        return None
    cmd_word = parts[0]
    if cmd_word not in valid_cmds:
        return None
    action_cmd = valid_cmds[cmd_word]
    if action_cmd in ("fd", "bk", "rt", "lt"):
        if len(parts) < 2:
            return None
        try:
            val = float(parts[1])
        except ValueError:
            return None
        return (action_cmd, val)
    return None


def check_command_matches_step(user_input: str, expected_step: dict, valid_cmds: dict) -> tuple:
    """
    Verifica si el input del usuario coincide con el paso esperado.
    Retorna (ok: bool, mensaje: str)
    """
    parsed = parse_command(user_input, valid_cmds)
    if parsed is None:
        # Ver si al menos el comando existe
        parts = user_input.strip().upper().split()
        if parts and parts[0] not in valid_cmds:
            return False, f"Comando '{parts[0]}' no existe. Usá: {', '.join(valid_cmds.keys())}"
        return False, "Formato incorrecto. Ejemplo: ADELANTE 4"

    expected_action = expected_step["action"]
    if parsed[0] != expected_action[0]:
        # Comando correcto pero distinto al esperado
        return False, f"Comando válido pero no es el siguiente paso 🐢"
    if abs(parsed[1] - expected_action[1]) > 0.01:
        return False, f"El número no es correcto. Intentá con {int(expected_action[1])}"

    return True, expected_step["desc"]

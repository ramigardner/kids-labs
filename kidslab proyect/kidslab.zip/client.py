"""
ASPR Oracle Lab v2 — Cliente Pygame
Estética Commodore 64 · Tortuga Logo · PvP Puzzle Race

Layout:
  ┌──────────────────────────────────────────────┐
  │         ZONA ANIMACIÓN (60%)                 │
  │  Avatar camina → Terminal → Tortuga dibuja   │
  ├────────────┬─────────────────────────────────┤
  │  STATS     │   CONSOLA LOGO (comandos)        │  40%
  │  (25%)     │   (75%)                          │
  └────────────┴─────────────────────────────────┘
"""

import pygame
import threading
import socket
import json
import time
import math
import random
import sys
import os
from typing import Optional

# Importar módulos propios
sys.path.insert(0, os.path.dirname(__file__))
from puzzle import Turtle, LEVELS, CELL, C64
from sound import sfx

# ─── Dimensiones ──────────────────────────────────────────────────────────────
W, H = 1280, 800
FPS  = 60

ANIM_H   = int(H * 0.60)   # zona animación
PANEL_Y  = ANIM_H           # inicio zona control
PANEL_H  = H - ANIM_H       # altura zona control
STATS_W  = int(W * 0.22)    # ancho panel stats
CONSOLE_X= STATS_W          # inicio consola
CONSOLE_W= W - STATS_W      # ancho consola

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 9999

# ─── Paleta C64 extendida ─────────────────────────────────────────────────────
BG_COLOR   = (16,  16,  64)   # azul Commodore oscuro
GRID_COLOR = (30,  30,  90)
BORDER_COL = (100, 100, 255)
TEXT_COL   = C64["white"]
DIM_COL    = C64["mid_grey"]
CURSOR_COL = C64["yellow"]
ERR_COL    = C64["red"]
OK_COL     = C64["lt_green"]
HACKER_COL = (255, 80,  80)
NERD_COL   = (80,  200, 255)


# ─── Fuentes pixeladas ────────────────────────────────────────────────────────
def load_fonts():
    mono = pygame.font.match_font(
        "px437ibmvga8x16,couriercode,couriernew,lucidaconsole,monospace,courier")
    sans = pygame.font.match_font(
        "pressstart2p,04b03,04b21,verdana,tahoma,arial")
    try:
        f = {
            "title": pygame.font.Font(sans,  20),
            "lg":    pygame.font.Font(mono,  18),
            "md":    pygame.font.Font(mono,  14),
            "sm":    pygame.font.Font(mono,  12),
            "xs":    pygame.font.Font(mono,  10),
            "emoji": pygame.font.SysFont("segoeuiemoji,noto emoji", 24),
        }
    except Exception:
        f = {k: pygame.font.SysFont("monospace", s)
             for k, s in [("title",20),("lg",18),("md",14),("sm",12),("xs",10),("emoji",22)]}
    return f


# ─── Utilidades de dibujo C64 ─────────────────────────────────────────────────

def px(surf, text, x, y, font, color=None, center=False, right=False, shadow=True):
    color = color or TEXT_COL
    if shadow:
        sh = font.render(text, False, (0,0,0))
        if center: surf.blit(sh, (x - sh.get_width()//2 + 1, y + 1))
        elif right: surf.blit(sh, (x - sh.get_width() + 1, y + 1))
        else: surf.blit(sh, (x + 1, y + 1))
    rendered = font.render(text, False, color)
    rx = x - rendered.get_width()//2 if center else (x - rendered.get_width() if right else x)
    surf.blit(rendered, (rx, y))
    return rendered.get_width()

def draw_border_box(surf, rect, color=BORDER_COL, fill=None, thickness=2):
    if fill:
        pygame.draw.rect(surf, fill, rect)
    pygame.draw.rect(surf, color, rect, thickness)
    # Esquinas pixeladas C64 style
    x, y, w, h = rect
    for corner in [(x,y),(x+w-2,y),(x,y+h-2),(x+w-2,y+h-2)]:
        pygame.draw.rect(surf, C64["white"], (*corner, 2, 2))

def draw_grid(surf, rect, cell=20, color=GRID_COLOR):
    x, y, w, h = rect
    for gx in range(x, x+w, cell):
        pygame.draw.line(surf, color, (gx, y), (gx, y+h))
    for gy in range(y, y+h, cell):
        pygame.draw.line(surf, color, (x, gy), (x+w, gy))

def draw_bar_c64(surf, x, y, w, h, val, maxv, color):
    pygame.draw.rect(surf, (10,10,40), (x, y, w, h))
    fill = int(w * val / max(maxv,1))
    if fill > 0:
        # Efecto pixelado: bloques de 4px
        for bx in range(0, fill, 4):
            bw = min(3, fill - bx)
            pygame.draw.rect(surf, color, (x+bx, y+1, bw, h-2))
    pygame.draw.rect(surf, C64["mid_grey"], (x, y, w, h), 1)

def scanlines(surf, rect, alpha=25):
    x, y, w, h = rect
    sl = pygame.Surface((w, h), pygame.SRCALPHA)
    for gy in range(0, h, 3):
        pygame.draw.line(sl, (0,0,0,alpha), (0,gy), (w,gy))
    surf.blit(sl, (x, y))


# ─── Avatar que camina ────────────────────────────────────────────────────────

class WalkingAvatar:
    """Avatar píxel que camina de izquierda a derecha hacia la terminal."""
    def __init__(self, role: str, start_x: int, y: int):
        self.role = role
        self.x = float(start_x)
        self.y = y
        self.target_x = float(start_x)
        self.walking = False
        self.at_terminal = False
        self.frame = 0
        self.frame_t = 0
        self.color = HACKER_COL if role == "hacker" else NERD_COL
        self.direction = 1  # 1=derecha, -1=izquierda
        self.idle_bounce = 0.0
        self.t = 0.0
        # Partículas de pasos
        self.step_particles = []

    def walk_to(self, target: float):
        self.target_x = target
        self.walking = True
        self.direction = 1 if target > self.x else -1

    def arrive(self):
        self.at_terminal = True
        self.walking = False

    def update(self, dt: float):
        self.t += dt
        self.frame_t += dt
        if self.frame_t > 0.12:
            self.frame_t = 0
            self.frame = (self.frame + 1) % 4

        if self.walking:
            speed = 120 * dt
            diff = self.target_x - self.x
            if abs(diff) < speed:
                self.x = self.target_x
                self.walking = False
                self.at_terminal = True
                sfx.beep(220, 60)
            else:
                self.x += math.copysign(speed, diff)
                # Partícula de paso
                if self.frame % 2 == 0:
                    self.step_particles.append({
                        "x": self.x, "y": self.y + 24,
                        "vy": -0.5, "life": 0.4,
                    })
        else:
            self.idle_bounce = math.sin(self.t * 3) * 2

        for p in self.step_particles:
            p["y"] += p["vy"]
            p["life"] -= dt
        self.step_particles = [p for p in self.step_particles if p["life"] > 0]

    def draw(self, surf: pygame.Surface, fonts: dict):
        for p in self.step_particles:
            alpha = int(p["life"] * 200)
            s = pygame.Surface((4,4), pygame.SRCALPHA)
            s.fill((*self.color, alpha))
            surf.blit(s, (int(p["x"]), int(p["y"])))

        bx = int(self.x)
        by = int(self.y + self.idle_bounce)
        f = self.frame
        col = self.color
        dk = tuple(max(0,c-80) for c in col)

        # Cuerpo 16x24 pixeles, estilo NES
        # Piernas animadas
        leg_offset = [0, 3, 0, -3][f]
        pygame.draw.rect(surf, dk,  (bx-4, by+12, 4, 10))          # pierna izq
        pygame.draw.rect(surf, dk,  (bx,   by+12+leg_offset, 4, 10)) # pierna der
        # Pies
        pygame.draw.rect(surf, C64["brown"], (bx-5, by+20, 5, 4))
        pygame.draw.rect(surf, C64["brown"], (bx,   by+20+leg_offset, 5, 4))
        # Cuerpo
        pygame.draw.rect(surf, col, (bx-6, by, 12, 14))
        # Cabeza
        pygame.draw.rect(surf, (220,180,140), (bx-5, by-10, 10, 10))
        # Ojos
        pygame.draw.rect(surf, C64["black"], (bx-3, by-7, 2, 2))
        pygame.draw.rect(surf, C64["black"], (bx+1, by-7, 2, 2))
        # Boca según estado
        if self.at_terminal:
            pygame.draw.rect(surf, C64["yellow"], (bx-2, by-3, 4, 2))  # sonrisa
        else:
            pygame.draw.rect(surf, C64["mid_grey"], (bx-1, by-3, 2, 2))  # neutral
        # Brazos
        arm_swing = [2,0,-2,0][f]
        pygame.draw.rect(surf, col, (bx-9, by+2+arm_swing, 3, 8))
        pygame.draw.rect(surf, col, (bx+6, by+2-arm_swing, 3, 8))
        # Accesorio por rol
        if self.role == "hacker":
            pygame.draw.rect(surf, C64["dk_grey"], (bx-5, by-14, 10, 4))  # gorra
            pygame.draw.rect(surf, C64["red"],     (bx-7, by-12, 3, 2))   # borde
        else:
            pygame.draw.rect(surf, C64["yellow"], (bx-5, by-14, 10, 4))   # casco
            pygame.draw.rect(surf, C64["white"],  (bx-4, by-12, 8, 2))    # reflejo
        # Label
        px(surf, self.role.upper(), bx, by-22, fonts["xs"], col, center=True, shadow=True)


# ─── Terminal / Puerta ────────────────────────────────────────────────────────

class Terminal:
    """La puerta/terminal que se abre cuando se completa el puzzle."""
    def __init__(self, x: int, y: int, w: int, h: int):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.open_progress = 0.0   # 0=cerrada 1=abierta
        self.blink_t = 0.0
        self.glow_t = 0.0
        self.sparks = []
        self.opening = False

    def start_open(self):
        self.opening = True
        sfx.play("door")

    def update(self, progress: float, dt: float):
        self.blink_t += dt
        self.glow_t += dt
        if self.opening:
            self.open_progress = min(1.0, self.open_progress + dt * 0.8)
            if random.random() < 0.4:
                self.sparks.append({
                    "x": self.x + random.randint(0, self.w),
                    "y": self.y + random.randint(0, self.h//2),
                    "vx": random.uniform(-2, 2),
                    "vy": random.uniform(-3, -1),
                    "life": random.uniform(0.3, 0.8),
                    "color": random.choice([C64["yellow"], C64["white"], C64["lt_green"]]),
                })
        for s in self.sparks:
            s["x"] += s["vx"]; s["y"] += s["vy"]; s["life"] -= dt
        self.sparks = [s for s in self.sparks if s["life"] > 0]

    def draw(self, surf: pygame.Surface, level_color: tuple, fonts: dict):
        x, y, w, h = self.x, self.y, self.w, self.h
        glow = abs(math.sin(self.glow_t * 2))

        # Marco de la puerta (pixelado)
        border_col = tuple(int(c * (0.6 + 0.4 * glow)) for c in level_color)
        pygame.draw.rect(surf, (10, 10, 40), (x, y, w, h))
        draw_border_box(surf, (x, y, w, h), border_col, thickness=3)

        # Puerta partiéndose en dos mitades que se abren
        half_w = int(w/2 * (1 - self.open_progress))
        if half_w > 0:
            pygame.draw.rect(surf, (30, 30, 100), (x, y+2, half_w, h-4))
            pygame.draw.rect(surf, (30, 30, 100), (x+w-half_w, y+2, half_w, h-4))
            # Detalle de la puerta
            for ky in range(y+8, y+h-8, 12):
                pygame.draw.rect(surf, border_col, (x+4, ky, half_w-8, 2))
                pygame.draw.rect(surf, border_col, (x+w-half_w+4, ky, half_w-8, 2))

        # Luz interior cuando se abre
        if self.open_progress > 0.1:
            light_w = int((w-4) * self.open_progress * 0.8)
            light_h = h - 8
            light_x = x + (w - light_w) // 2
            s = pygame.Surface((light_w, light_h), pygame.SRCALPHA)
            alpha = int(self.open_progress * 120)
            s.fill((*level_color, alpha))
            surf.blit(s, (light_x, y+4))

        # Texto de nivel
        blink = int(self.blink_t * 3) % 2 == 0
        lv_txt = "NIVEL BLOQUEADO" if self.open_progress < 0.1 else ("ABIERTO!" if self.open_progress > 0.9 else "ABRIENDO...")
        txt_col = C64["yellow"] if blink else level_color
        px(surf, lv_txt, x + w//2, y + h//2 - 8, fonts["xs"], txt_col, center=True)

        # Sparks
        for s in self.sparks:
            alpha = int(s["life"] * 255)
            sp = pygame.Surface((4,4), pygame.SRCALPHA)
            sp.fill((*s["color"], alpha))
            surf.blit(sp, (int(s["x"]), int(s["y"])))


# ─── Red ──────────────────────────────────────────────────────────────────────

class Net:
    def __init__(self):
        self.sock: Optional[socket.socket] = None
        self.connected = False
        self._msgs = []
        self._lock = threading.Lock()

    def connect(self, host, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        self.sock.settimeout(0.05)
        self.connected = True
        threading.Thread(target=self._recv, daemon=True).start()

    def _recv(self):
        buf = b""
        while self.connected:
            try:
                data = self.sock.recv(8192)
                if not data:
                    self.connected = False; break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    try:
                        with self._lock:
                            self._msgs.append(json.loads(line.decode()))
                    except Exception:
                        pass
            except socket.timeout:
                pass
            except Exception:
                self.connected = False; break

    def send(self, msg: dict):
        if self.connected:
            try:
                self.sock.sendall((json.dumps(msg)+"\n").encode())
            except Exception:
                self.connected = False

    def poll(self) -> list:
        with self._lock:
            m = self._msgs[:]
            self._msgs.clear()
        return m

    def disconnect(self):
        self.connected = False
        if self.sock: self.sock.close()


# ─── Pantallas auxiliares ─────────────────────────────────────────────────────

class LoginScreen:
    def __init__(self, fonts):
        self.fonts = fonts
        self.name = ""
        self.role = "nerd"
        self.host = SERVER_HOST
        self.field = "name"   # name / host
        self.t = 0.0
        self.error = ""
        self.done = False
        self.result = {}

    def handle(self, ev):
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_TAB:
                self.field = "host" if self.field == "name" else "name"
                sfx.beep(440, 40)
            elif ev.key == pygame.K_1: self.role = "hacker"; sfx.beep(330,40)
            elif ev.key == pygame.K_2: self.role = "nerd";   sfx.beep(440,40)
            elif ev.key == pygame.K_RETURN: self._go()
            elif ev.key == pygame.K_BACKSPACE:
                if self.field == "name": self.name = self.name[:-1]
                else: self.host = self.host[:-1]
            else:
                ch = ev.unicode
                if ch and ch.isprintable():
                    if self.field == "name" and len(self.name) < 10:
                        self.name += ch
                    elif self.field == "host" and len(self.host) < 40:
                        self.host += ch
        elif ev.type == pygame.MOUSEBUTTONDOWN:
            mx, my = ev.pos
            if 420 <= mx <= 540 and 380 <= my <= 408: self.role = "hacker"; sfx.beep(330,40)
            if 560 <= mx <= 680 and 380 <= my <= 408: self.role = "nerd";   sfx.beep(440,40)
            if 460 <= mx <= 820 and 430 <= my <= 462: self._go()

    def _go(self):
        if not self.name.strip():
            self.error = "INGRESA TU NOMBRE"; sfx.play("error"); return
        h = self.host.strip() or SERVER_HOST
        hp = h.split(":")
        self.result = {"name": self.name.strip(), "role": self.role,
                       "host": hp[0], "port": int(hp[1]) if len(hp)>1 else SERVER_PORT}
        self.done = True

    def draw(self, surf):
        self.t += 0.016
        surf.fill(BG_COLOR)
        draw_grid(surf, (0,0,W,H), 32, GRID_COLOR)

        # Título estilo C64 boot screen
        px(surf, "* * * ASPR ORACLE LAB v2.0 * * *", W//2, 60, self.fonts["lg"], C64["cyan"], center=True)
        px(surf, "64K RAM SYSTEM  38911 BASIC BYTES FREE", W//2, 86, self.fonts["sm"], DIM_COL, center=True)
        px(surf, "HACKERS  VS  NERDS", W//2, 118, self.fonts["title"], C64["yellow"], center=True)

        cy = 200
        # Panel
        draw_border_box(surf, (380, cy, 520, 300), BORDER_COL, fill=(10,10,50))

        # Nombre
        px(surf, "NOMBRE DE JUGADOR:", 400, cy+20, self.fonts["sm"], DIM_COL)
        bc1 = CURSOR_COL if self.field=="name" else C64["mid_grey"]
        draw_border_box(surf, (400, cy+38, 480, 26), bc1, fill=(0,0,30))
        disp = (self.name + ("|" if self.field=="name" and int(self.t*2)%2==0 else "")) or " "
        px(surf, disp, 406, cy+44, self.fonts["sm"], C64["white"])

        # Host
        px(surf, "SERVIDOR (IP:PUERTO):", 400, cy+82, self.fonts["sm"], DIM_COL)
        bc2 = CURSOR_COL if self.field=="host" else C64["mid_grey"]
        draw_border_box(surf, (400, cy+100, 480, 26), bc2, fill=(0,0,30))
        disp2 = (self.host + ("|" if self.field=="host" and int(self.t*2)%2==0 else ""))
        px(surf, disp2, 406, cy+106, self.fonts["xs"], C64["white"])

        # Rol
        px(surf, "ELEGÍ BANDO  [1] o [2]:", 400, cy+146, self.fonts["sm"], DIM_COL)
        hk = HACKER_COL if self.role=="hacker" else C64["mid_grey"]
        nd = NERD_COL   if self.role=="nerd"   else C64["mid_grey"]
        draw_border_box(surf, (400, cy+162, 115, 28), hk, fill=(30,5,5) if self.role=="hacker" else (10,10,40))
        px(surf, "[1] HACKER", 458, cy+169, self.fonts["xs"], hk, center=True)
        draw_border_box(surf, (525, cy+162, 115, 28), nd, fill=(5,5,30) if self.role=="nerd" else (10,10,40))
        px(surf, "[2] NERD",   583, cy+169, self.fonts["xs"], nd, center=True)

        # Conectar
        pulse = abs(math.sin(self.t*3))
        bc = tuple(int(80+pulse*175) for _ in range(3))
        draw_border_box(surf, (420, cy+210, 440, 36), bc, fill=(10,30,10))
        px(surf, "ENTER - CONECTAR AL SERVIDOR", W//2, cy+220, self.fonts["sm"], C64["lt_green"], center=True)

        if self.error:
            px(surf, "? " + self.error, W//2, cy+266, self.fonts["sm"], ERR_COL, center=True)

        # TAB hint
        px(surf, "TAB=CAMBIAR CAMPO", W//2, H-40, self.fonts["xs"], DIM_COL, center=True)
        # Cursor parpadeante
        if int(self.t*2)%2==0:
            px(surf, "READY.", W//2, H-24, self.fonts["sm"], C64["yellow"], center=True)


class WaitingScreen:
    def __init__(self, fonts, name, role):
        self.fonts = fonts; self.name = name; self.role = role
        self.t = 0.0; self.dots = 0; self.dt2 = 0.0

    def draw(self, surf):
        self.t += 0.016; self.dt2 += 0.016
        if self.dt2 > 0.5: self.dt2=0; self.dots=(self.dots+1)%4
        surf.fill(BG_COLOR)
        draw_grid(surf, (0,0,W,H), 32, GRID_COLOR)
        col = HACKER_COL if self.role=="hacker" else NERD_COL
        px(surf, f"CONECTADO COMO: {self.name.upper()}", W//2, H//2-60, self.fonts["lg"], col, center=True)
        px(surf, f"ROL: {self.role.upper()}", W//2, H//2-30, self.fonts["md"], C64["yellow"], center=True)
        px(surf, "ESPERANDO AL OPONENTE" + "."*self.dots, W//2, H//2+10, self.fonts["md"], DIM_COL, center=True)
        if int(self.t*2)%2==0:
            px(surf, "█", W//2+140, H//2+10, self.fonts["md"], C64["white"], center=True)


class GameOverScreen:
    def __init__(self, fonts, winner_pid, my_pid, players):
        self.fonts = fonts
        self.won = winner_pid == my_pid
        self.t = 0.0
        wname = players.get(winner_pid,{}).get("name","???") if players else "???"
        self.wname = wname
        sfx.play("win" if self.won else "error")

    def draw(self, surf):
        self.t += 0.016
        surf.fill(BG_COLOR)
        draw_grid(surf, (0,0,W,H), 32, GRID_COLOR)
        col = C64["lt_green"] if self.won else ERR_COL
        title = "* VICTORIA! *" if self.won else "  DERROTA   "
        px(surf, title, W//2, H//2-80, self.fonts["title"], col, center=True)
        px(surf, f"GANADOR: {self.wname.upper()}", W//2, H//2-30, self.fonts["lg"], C64["yellow"], center=True)
        if int(self.t*2)%2==0:
            px(surf, "CERRÁ LA VENTANA PARA SALIR", W//2, H//2+40, self.fonts["sm"], DIM_COL, center=True)


# ─── Pantalla principal del juego ─────────────────────────────────────────────

class GameScreen:
    def __init__(self, fonts, pid, role, name, net: Net):
        self.fonts = fonts
        self.pid = pid
        self.role = role
        self.name = name
        self.net = net
        self.t = 0.0
        self.blink_t = 0.0

        # Estado
        self.state = {}
        self.pasos = []
        self.step_index = 0
        self.input_text = ""
        self.input_active = True
        self.log = []        # [(msg, color)]
        self.time_remaining = 120.0
        self.level_data = {}
        self.rival_step = 0
        self.rival_total = 0

        # Layout
        self.anim_rect  = (0, 0, W, ANIM_H)
        self.stats_rect = (0, PANEL_Y, STATS_W, PANEL_H)
        self.console_rect = (CONSOLE_X, PANEL_Y, CONSOLE_W, PANEL_H)

        # Tortuga logo centrada en la zona de animación
        # Canvas centrado
        self.canvas_w = 200
        self.canvas_h = 200
        self.canvas_x = W // 2 - self.canvas_w // 2
        self.canvas_y = ANIM_H // 2 - self.canvas_h // 2 - 10
        # Tortuga empieza en centro del canvas
        self.turtle = Turtle()
        self._reset_turtle()

        # Avatar que camina
        start_x = 80 if role == "hacker" else W - 80
        self.avatar = WalkingAvatar(role, start_x, ANIM_H - 90)
        self.avatar.walk_to(self.canvas_x - 60 if role == "hacker" else self.canvas_x + self.canvas_w + 60)

        # Terminal (puerta)
        door_w, door_h = 120, 140
        self.terminal = Terminal(
            self.canvas_x + self.canvas_w//2 - door_w//2,
            ANIM_H//2 - door_h//2 - 40,
            door_w, door_h
        )

        # Rival avatar (simplificado)
        rival_x = W - 80 if role == "hacker" else 80
        rival_role = "nerd" if role == "hacker" else "hacker"
        self.rival_avatar = WalkingAvatar(rival_role, rival_x, ANIM_H - 90)

        # Efectos
        self.result_msg = ""
        self.result_col = TEXT_COL
        self.result_t = 0.0
        self.level_complete_flash = 0.0
        self.show_turtle = False
        self.level_color = C64["yellow"]

        # Stats propios
        self.power = 50
        self.karma = 0
        self.wins = 0
        self.has_pet = False
        self.pet_data = {}
        self.pet_hunger = 100
        self.pet_anim_t = 0.0
        self.pet_visible = False

    def _reset_turtle(self):
        # Origen de la tortuga en el centro del canvas (en celdas)
        ox = self.canvas_w // (2 * CELL)
        oy = self.canvas_h // (2 * CELL)
        lv = LEVELS[0] if self.level_data == {} else None
        color = self.level_color
        total = len(self.pasos) if self.pasos else 9
        self.turtle.reset(float(ox), float(oy), color, total)

    def set_level(self, state: dict, pasos: list):
        self.state = state
        self.pasos = pasos
        lv = state.get("level") or {}
        self.level_data = lv
        self.step_index = 0
        self.input_text = ""
        self.show_turtle = False
        self.level_complete_flash = 0.0
        self.terminal.open_progress = 0.0
        self.terminal.opening = False

        # Color del nivel
        lvl_id = lv.get("id", 1)
        lv_full = next((l for l in LEVELS if l["id"] == lvl_id), LEVELS[0])
        self.level_color = lv_full["color"]
        self.turtle.color = self.level_color

        ox = self.canvas_w // (2 * CELL)
        oy = self.canvas_h // (2 * CELL)
        self.turtle.reset(float(ox), float(oy), self.level_color, len(pasos))

        # Avatar camina de vuelta
        if not self.avatar.at_terminal:
            pass
        self.show_turtle = True

        sfx.play("level_start")
        self.add_log(f"NIVEL {lvl_id}: {lv.get('titulo','')}", C64["yellow"])
        self.add_log(lv.get("concepto",""), DIM_COL)

    def update_state(self, state: dict):
        self.state = state
        me = state.get("players", {}).get(self.pid, {})
        if me:
            self.power = me.get("power", 50)
            self.karma = me.get("karma", 0)
            self.wins = me.get("wins", 0)
            self.step_index = me.get("step_index", 0)
            if me.get("has_pet") and not self.has_pet:
                self.has_pet = True
                self.pet_data = me.get("pet", {})
                self.pet_visible = True
                sfx.play("pet")
                self.add_log(f"MASCOTA: {self.pet_data.get('name','')} {self.pet_data.get('emoji','')}!", C64["lt_green"])
            if self.has_pet:
                self.pet_hunger = me.get("pet", {}).get("hunger", 100)
            # Actualizar tortuga
            self.turtle.step_index = self.step_index

        # Rival
        for rpid, rp in state.get("players",{}).items():
            if rpid != self.pid:
                self.rival_step = rp.get("step_index", 0)

        self.time_remaining = state.get("time_remaining", 120)
        self.rival_total = len(self.pasos)

    def handle_event(self, ev):
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_BACKSPACE:
                self.input_text = self.input_text[:-1]
                sfx.beep(200, 20)
            elif ev.key == pygame.K_RETURN:
                self._submit()
            elif ev.key == pygame.K_ESCAPE:
                self.input_text = ""
            else:
                ch = ev.unicode
                if ch and ch.isprintable() and len(self.input_text) < 30:
                    self.input_text += ch.upper()
                    sfx.beep(880, 15)
        elif ev.type == pygame.MOUSEBUTTONDOWN:
            mx, my = ev.pos
            # Feed pet button
            fx, fy = STATS_W - 10, PANEL_Y + PANEL_H - 40
            if CONSOLE_X + 10 <= mx <= CONSOLE_X + 180 and PANEL_Y + PANEL_H - 40 <= my <= PANEL_Y + PANEL_H - 12:
                self.net.send({"action": "feed_pet", "pid": self.pid})

    def _submit(self):
        inp = self.input_text.strip()
        if not inp:
            return
        self.net.send({"action": "step", "pid": self.pid, "input": inp})
        self.input_text = ""

    def on_step_result(self, result: dict):
        correct = result.get("correct", False)
        msg = result.get("msg", "")
        if correct:
            sfx.play("piece")
            self.add_log(f"OK  {msg}", OK_COL)
            self.result_msg = "CORRECTO!"
            self.result_col = OK_COL
            # Ejecutar la acción en la tortuga
            step_idx = result.get("step", 1) - 1
            if 0 <= step_idx < len(self.pasos):
                action = self.pasos[step_idx]["action"]
                self.turtle.execute(action)
            if result.get("level_complete"):
                self.terminal.start_open()
                self.level_complete_flash = 1.0
                sfx.play("win")
                self.add_log("NIVEL COMPLETADO!", C64["yellow"])
        else:
            sfx.play("error")
            self.turtle.shake_error()
            self.add_log(f"ERR {msg}", ERR_COL)
            self.result_msg = "INCORRECTO"
            self.result_col = ERR_COL
        self.result_t = 2.5

    def add_log(self, msg: str, color=None):
        self.log.append({"msg": msg[:50], "color": color or TEXT_COL})
        if len(self.log) > 8:
            self.log.pop(0)

    def update(self, dt: float):
        self.t += dt
        self.blink_t += dt
        self.avatar.update(dt)
        self.rival_avatar.update(dt)
        self.turtle.update(dt)
        self.terminal.update(self.step_index / max(len(self.pasos),1), dt)
        self.result_t = max(0, self.result_t - dt)
        self.level_complete_flash = max(0, self.level_complete_flash - dt * 1.5)
        self.pet_anim_t += dt

    def draw(self, surf: pygame.Surface):
        # ── Zona animación ────────────────────────────────────────────────────
        self._draw_anim(surf)

        # ── Zona control inferior ─────────────────────────────────────────────
        self._draw_stats(surf)
        self._draw_console(surf)

        # ── Divisores ─────────────────────────────────────────────────────────
        role_col = HACKER_COL if self.role == "hacker" else NERD_COL
        pygame.draw.line(surf, role_col, (0, ANIM_H), (W, ANIM_H), 2)
        pygame.draw.line(surf, BORDER_COL, (STATS_W, PANEL_Y), (STATS_W, H), 1)

        # ── Flash de nivel completo ───────────────────────────────────────────
        if self.level_complete_flash > 0:
            fl = pygame.Surface((W, H), pygame.SRCALPHA)
            fl.fill((*self.level_color, int(self.level_complete_flash * 80)))
            surf.blit(fl)

        scanlines(surf, (0, 0, W, H), 15)

    def _draw_anim(self, surf: pygame.Surface):
        rx, ry, rw, rh = self.anim_rect
        # Fondo con gradiente simulado por filas
        for dy in range(rh):
            ratio = dy / rh
            base = BG_COLOR
            row_col = tuple(int(c * (0.7 + 0.3 * (1-ratio))) for c in base)
            pygame.draw.line(surf, row_col, (0, ry+dy), (rw, ry+dy))

        draw_grid(surf, (rx, ry, rw, rh), 32, GRID_COLOR)

        # Suelo pixelado
        ground_y = ANIM_H - 50
        for gx in range(0, W, 16):
            col = C64["mid_grey"] if (gx//16) % 2 == 0 else (50,50,100)
            pygame.draw.rect(surf, col, (gx, ground_y, 16, 4))

        # ── Canvas de la tortuga ──────────────────────────────────────────────
        if self.show_turtle:
            # Fondo del canvas
            canvas_surf = pygame.Surface((self.canvas_w, self.canvas_h))
            canvas_surf.fill((8, 8, 30))
            # Grid fino
            for cx in range(0, self.canvas_w, CELL):
                pygame.draw.line(canvas_surf, (20,20,60), (cx,0), (cx,self.canvas_h))
            for cy in range(0, self.canvas_h, CELL):
                pygame.draw.line(canvas_surf, (20,20,60), (0,cy), (self.canvas_w,cy))
            surf.blit(canvas_surf, (self.canvas_x, self.canvas_y))
            draw_border_box(surf, (self.canvas_x, self.canvas_y, self.canvas_w, self.canvas_h),
                          self.level_color, thickness=2)

            # Dibuja tortuga sobre el canvas
            self.turtle.draw(surf, self.canvas_x, self.canvas_y)

            # Barra de progreso del puzzle
            prog = self.step_index / max(len(self.pasos), 1)
            bar_y = self.canvas_y + self.canvas_h + 8
            draw_bar_c64(surf, self.canvas_x, bar_y, self.canvas_w, 8,
                        int(prog*100), 100, self.level_color)
            px(surf, f"{self.step_index}/{len(self.pasos)} PASOS", self.canvas_x, bar_y+10,
               self.fonts["xs"], self.level_color)

        # ── Terminal ──────────────────────────────────────────────────────────
        lv_color = self.level_color
        self.terminal.draw(surf, lv_color, self.fonts)

        # ── Avatares ──────────────────────────────────────────────────────────
        self.rival_avatar.draw(surf, self.fonts)
        self.avatar.draw(surf, self.fonts)

        # ── Barra rival ───────────────────────────────────────────────────────
        rival_col = HACKER_COL if self.role == "nerd" else NERD_COL
        riv_prog = self.rival_step / max(self.rival_total, 1)
        bar_x_rv = self.rival_avatar.x - 40
        px(surf, "RIVAL:", int(bar_x_rv), ANIM_H - 34, self.fonts["xs"], rival_col)
        draw_bar_c64(surf, int(bar_x_rv), ANIM_H-20, 80, 6, int(riv_prog*100), 100, rival_col)

        # ── Título del nivel ──────────────────────────────────────────────────
        lv = self.level_data
        if lv:
            lv_title = f"{lv.get('emoji_titulo','')} {lv.get('titulo','')}"
            px(surf, lv_title, W//2, 12, self.fonts["md"], lv_color, center=True)

        # ── Pet mascota ───────────────────────────────────────────────────────
        if self.pet_visible and self.has_pet:
            pet_x = 120 if self.role == "hacker" else W - 120
            pet_y = ground_y - 50
            pet_emoji = self.pet_data.get("emoji", "⭐")
            pet_name  = self.pet_data.get("name", "")
            bounce = int(math.sin(self.pet_anim_t * 3) * 5)
            pet_surf = self.fonts["emoji"].render(pet_emoji, True, C64["white"])
            surf.blit(pet_surf, (pet_x - pet_surf.get_width()//2, pet_y + bounce))
            px(surf, pet_name, pet_x, pet_y + 30, self.fonts["xs"],
               HACKER_COL if self.role=="hacker" else NERD_COL, center=True)
            draw_bar_c64(surf, pet_x-25, pet_y+42, 50, 5, self.pet_hunger, 100, C64["lt_green"])

    def _draw_stats(self, surf: pygame.Surface):
        rx, ry, rw, rh = self.stats_rect
        pygame.draw.rect(surf, (10, 10, 40), (rx, ry, rw, rh))
        draw_border_box(surf, (rx, ry, rw, rh), BORDER_COL)

        role_col = HACKER_COL if self.role == "hacker" else NERD_COL
        icon = "☠" if self.role == "hacker" else "S"  # S de shield
        px(surf, f"{self.name[:8].upper()}", rx+8, ry+8, self.fonts["sm"], role_col)
        px(surf, self.role.upper(), rx+8, ry+24, self.fonts["xs"], DIM_COL)

        lh = 38
        stats = [
            ("POWER",  self.power,     100, role_col),
            ("KARMA",  min(self.karma, 200), 200, C64["yellow"]),
            ("HAMBRE", self.pet_hunger, 100, C64["lt_green"]),
        ]
        for i, (lbl, val, maxv, col) in enumerate(stats):
            sy = ry + 50 + i * lh
            px(surf, lbl, rx+8, sy, self.fonts["xs"], DIM_COL)
            draw_bar_c64(surf, rx+8, sy+13, rw-16, 9, val, maxv, col)
            px(surf, str(val), rx+rw-8, sy, self.fonts["xs"], col, right=True)

        # Timer
        ty = ry + 50 + 3*lh + 4
        tr = self.time_remaining
        tl = 120
        t_col = OK_COL if tr > 60 else (C64["yellow"] if tr > 30 else ERR_COL)
        if tr < 10 and int(self.t*4)%2==0:
            px(surf, f"!!{int(tr)}s!!", rx+rw//2, ty, self.fonts["sm"], ERR_COL, center=True)
        else:
            px(surf, f"TIEMPO:{int(tr)}s", rx+rw//2, ty, self.fonts["xs"], t_col, center=True)
        draw_bar_c64(surf, rx+8, ty+16, rw-16, 7, int(tr), tl, t_col)

        # Wins
        py2 = ty + 32
        px(surf, f"WINS: {self.wins}", rx+8, py2, self.fonts["xs"], C64["yellow"])

        # Feed hint
        px(surf, "CTRL+F=ALIMENTAR", rx+rw//2, ry+rh-16, self.fonts["xs"], DIM_COL, center=True)

    def _draw_console(self, surf: pygame.Surface):
        rx, ry, rw, rh = self.console_rect
        pygame.draw.rect(surf, (6, 6, 26), (rx, ry, rw, rh))
        draw_border_box(surf, (rx, ry, rw, rh), BORDER_COL)

        role_col = HACKER_COL if self.role == "hacker" else NERD_COL

        # Header con nivel
        lv = self.level_data
        lv_id   = lv.get("id", "?")
        lv_nom  = lv.get("titulo", "---")
        lv_conc = lv.get("concepto", "")
        cmds_ok = lv.get("comandos_validos", [])

        px(surf, f"NIVEL {lv_id}: {lv_nom}", rx+10, ry+8, self.fonts["sm"], self.level_color)
        px(surf, lv_conc[:55], rx+10, ry+24, self.fonts["xs"], DIM_COL)

        # Comandos disponibles
        px(surf, "COMANDOS: " + "  ".join(cmds_ok), rx+10, ry+38, self.fonts["xs"], C64["cyan"])
        pygame.draw.line(surf, BORDER_COL, (rx, ry+52), (rx+rw, ry+52), 1)

        # Pasos del puzzle — paso actual destacado
        paso_y = ry + 58
        for i, paso in enumerate(self.pasos):
            if paso_y + 18 > ry + rh - 80:
                px(surf, f"...y {len(self.pasos)-i} pasos más", rx+10, paso_y, self.fonts["xs"], DIM_COL)
                break
            if i < self.step_index:
                col = C64["mid_grey"]; prefix = "  OK "
            elif i == self.step_index:
                # Parpadeo en el paso actual
                col = self.level_color if int(self.blink_t*3)%2==0 else C64["white"]
                prefix = "  >> "
                # Caja destacada
                draw_border_box(surf, (rx+6, paso_y-2, rw-12, 18), col, fill=(10,20,40))
            else:
                col = (40,40,80); prefix = "     "
            desc = paso.get("desc","")[:35]
            cmd  = paso.get("cmd","")
            px(surf, f"{prefix}{i+1}. {cmd:<16} {desc}", rx+8, paso_y, self.fonts["xs"], col)
            paso_y += 19

        pygame.draw.line(surf, BORDER_COL, (rx, ry+rh-72), (rx+rw, ry+rh-72), 1)

        # Log rápido
        log_y = ry+rh-70
        for entry in self.log[-3:]:
            px(surf, entry["msg"], rx+10, log_y, self.fonts["xs"], entry["color"])
            log_y += 16

        pygame.draw.line(surf, BORDER_COL, (rx, ry+rh-22), (rx+rw, ry+rh-22), 1)

        # Input line — estilo terminal C64
        cursor = "█" if int(self.blink_t*3)%2==0 else " "
        disp = f"READY. {self.input_text}{cursor}"
        px(surf, disp, rx+8, ry+rh-16, self.fonts["sm"], CURSOR_COL)

        # Resultado flotante
        if self.result_t > 0:
            alpha = min(1.0, self.result_t)
            col = tuple(int(c*alpha) for c in self.result_col)
            px(surf, self.result_msg, rx+rw//2, ry+rh-90, self.fonts["md"], col, center=True)


# ─── App ─────────────────────────────────────────────────────────────────────

class App:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("ASPR Oracle Lab v2 — Kids Lab")
        flags = 0
        self.screen = pygame.display.set_mode((W, H), flags)
        self.clock = pygame.time.Clock()
        self.fonts = load_fonts()
        sfx.init()

        self.net = Net()
        self.pid = f"p{int(time.time()*100)%99999:05d}"
        self.sid = "lab01"

        self.state = "login"
        self.login  = LoginScreen(self.fonts)
        self.wait   = None
        self.game   = None
        self.gameover = None

        self.player_name = ""
        self.player_role = ""

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    self.net.disconnect(); pygame.quit(); sys.exit()
                self._event(ev)
            self._network()
            self._update(dt)
            self._draw()
            pygame.display.flip()

    def _event(self, ev):
        # Feed pet shortcut global
        if ev.type == pygame.KEYDOWN:
            mods = pygame.key.get_mods()
            if ev.key == pygame.K_f and (mods & pygame.KMOD_CTRL):
                if self.game:
                    self.net.send({"action": "feed_pet", "pid": self.pid})

        if self.state == "login":
            self.login.handle(ev)
            if self.login.done:
                r = self.login.result
                self.player_name = r["name"]
                self.player_role = r["role"]
                try:
                    self.net.connect(r["host"], r["port"])
                    self.net.send({
                        "action": "join",
                        "pid": self.pid,
                        "sid": self.sid,
                        "name": self.player_name,
                        "role": self.player_role,
                    })
                    self.wait = WaitingScreen(self.fonts, self.player_name, self.player_role)
                    self.state = "waiting"
                    sfx.play("level_start")
                except Exception as e:
                    self.login.error = f"SIN CONEXION: {e}"
                    self.login.done = False
                    sfx.play("error")

        elif self.state == "game" and self.game:
            self.game.handle_event(ev)

    def _network(self):
        if not self.net.connected and self.state not in ("login","gameover"):
            self.state = "login"
            self.login = LoginScreen(self.fonts)
            self.login.error = "CONEXION PERDIDA"
            return

        for msg in self.net.poll():
            t = msg.get("type")

            if t == "level_start":
                state = msg.get("state", {})
                pasos = msg.get("pasos", [])
                if not self.game:
                    self.game = GameScreen(self.fonts, self.pid, self.player_role, self.player_name, self.net)
                self.game.set_level(state, pasos)
                self.game.update_state(state)
                self.state = "game"

            elif t in ("tick", "player_joined", "pet_update"):
                if self.game:
                    self.game.update_state(msg.get("state", {}))

            elif t == "step_result":
                if self.game and msg.get("pid") == self.pid:
                    self.game.on_step_result(msg.get("result", {}))
                elif self.game:
                    # Actualizar posición rival
                    self.game.update_state(msg.get("state", {}))

            elif t == "game_over":
                players = msg.get("state", {}).get("players", {})
                self.gameover = GameOverScreen(
                    self.fonts, msg.get("winner_pid"), self.pid, players)
                self.state = "gameover"

    def _update(self, dt):
        if self.state == "game" and self.game:
            self.game.update(dt)

    def _draw(self):
        if self.state == "login":
            self.login.draw(self.screen)
        elif self.state == "waiting" and self.wait:
            self.wait.draw(self.screen)
        elif self.state == "game" and self.game:
            self.game.draw(self.screen)
        elif self.state == "gameover" and self.gameover:
            self.gameover.draw(self.screen)
        else:
            self.screen.fill(BG_COLOR)


if __name__ == "__main__":
    App().run()

"""
game_engine.py — Motor de juego Hackers vs Nerds
Sin chat libre. Comandos predefinidos únicamente.
"""
import hashlib, json, random, time
from datetime import datetime

# ── Apodos automáticos (sin datos personales) ────────────────────────────────
HACKER_NAMES = ["Zorro-", "Sombra-", "Cobra-", "Trueno-", "Rayo-",
                "Fénix-", "Lobo-", "Tifón-", "Vortex-", "Glitch-"]
NERD_NAMES   = ["Búho-", "Linterna-", "Brújula-", "Escudo-", "Radar-",
                "Prisma-", "Nexo-", "Bitmap-", "Cifra-", "Kernel-"]

def random_alias(role: str) -> str:
    pool = HACKER_NAMES if role == "hacker" else NERD_NAMES
    return random.choice(pool) + str(random.randint(10, 99))

# ── Eventos del jardín para llenar la cadena ─────────────────────────────────
EVENTS = [
    {"animal": "🦉 Búho",  "action": "vio estrellas",   "valor": 7},
    {"animal": "🦊 Zorro", "action": "entregó mensajes", "valor": 3},
    {"animal": "🐾 Topo",  "action": "midió humedad",    "valor": 82},
    {"animal": "🐝 Abeja", "action": "contó flores",     "valor": 15},
    {"animal": "🦉 Búho",  "action": "detectó lluvia",   "valor": 4},
    {"animal": "🦊 Zorro", "action": "corrió metros",    "valor": 500},
    {"animal": "🐾 Topo",  "action": "encontró gusanos", "valor": 4},
    {"animal": "🐝 Abeja", "action": "produjo miel (g)", "valor": 2},
    {"animal": "🦉 Búho",  "action": "durmió horas",     "valor": 8},
    {"animal": "🦊 Zorro", "action": "escapó de lobos",  "valor": 2},
]

# ── Habilidades ───────────────────────────────────────────────────────────────
HACKER_SKILLS = [
    {"id":"ghost",    "name":"Ghost Write", "icon":"👻", "xp":0,   "cd":0,
     "desc":"Alterá un bloque cambiando su valor.",
     "uso":"ghost <N> <valor>", "ej":"ghost 3 999"},
    {"id":"smoke",    "name":"Smoke Screen","icon":"💨", "xp":40,  "cd":25,
     "desc":"Agregá un bloque falso al final.",
     "uso":"smoke <N>", "ej":"smoke 7"},
    {"id":"mirror",   "name":"Mirror",      "icon":"🪞", "xp":90,  "cd":40,
     "desc":"Copiá el sello del bloque anterior.",
     "uso":"mirror <N>", "ej":"mirror 5"},
    {"id":"timebomb", "name":"Time Bomb",   "icon":"💣", "xp":160, "cd":55,
     "desc":"Trampa que explota en 15 segundos.",
     "uso":"timebomb <N> <valor>", "ej":"timebomb 4 777"},
    {"id":"cascade",  "name":"Cascade",     "icon":"🌊", "xp":270, "cd":80,
     "desc":"Alterá DOS bloques a la vez.",
     "uso":"cascade <N1> <N2>", "ej":"cascade 2 7"},
]

NERD_SKILLS = [
    {"id":"scan",   "name":"Chain Scan",  "icon":"🔍", "xp":0,   "cd":0,
     "desc":"Mostrá qué bloques tienen el hash roto.",
     "uso":"scan", "ej":"scan"},
    {"id":"fix",    "name":"Hash Fix",    "icon":"🔧", "xp":0,   "cd":0,
     "desc":"Reparás el hash de un bloque.",
     "uso":"fix <N>", "ej":"fix 3"},
    {"id":"freeze", "name":"Freeze",      "icon":"❄️", "xp":40,  "cd":35,
     "desc":"El Hacker no puede atacar por 20 segundos.",
     "uso":"freeze", "ej":"freeze"},
    {"id":"shield", "name":"Shield",      "icon":"🛡️", "xp":90,  "cd":45,
     "desc":"Protegé un bloque por 30 segundos.",
     "uso":"shield <N>", "ej":"shield 5"},
    {"id":"rewind", "name":"Rewind",      "icon":"⏪", "xp":160, "cd":55,
     "desc":"Restaurá la cadena entera al estado inicial.",
     "uso":"rewind", "ej":"rewind"},
    {"id":"trace",  "name":"Trace",       "icon":"🕵️","xp":270, "cd":25,
     "desc":"Revelá exactamente qué cambió en un bloque.",
     "uso":"trace <N>", "ej":"trace 3"},
]

def _hash(index, data, prev):
    p = json.dumps({"i":index,"d":data,"p":prev}, sort_keys=True)
    return hashlib.sha256(p.encode()).hexdigest()

def _short(h): return h[:8].upper()

# ── Bloque ────────────────────────────────────────────────────────────────────
class Block:
    def __init__(self, index, data, prev_hash):
        self.index      = index
        self.data       = dict(data)
        self._orig      = dict(data)
        self.prev_hash  = prev_hash
        self.hash       = _hash(index, data, prev_hash)
        self._orig_hash = self.hash
        self.ts         = datetime.now().strftime("%H:%M:%S")
        self.tampered   = False
        self.protected  = False
        self.fake       = False

    def valid(self):
        return self.hash == _hash(self.index, self.data, self.prev_hash)

    def as_dict(self, reveal=False):
        return {
            "i":    self.index,
            "data": self.data,
            "prev": _short(self.prev_hash),
            "hash": _short(self.hash),
            "ts":   self.ts,
            "ok":   self.valid(),
            "prot": self.protected,
            "fake": self.fake if reveal else False,
            "tamp": self.tampered if reveal else False,
        }

# ── Cadena de juego ───────────────────────────────────────────────────────────
class Chain:
    def __init__(self):
        self.blocks: list[Block] = []
        self._snap: list[dict] = []
        prev = "0"*64
        for i, ev in enumerate(random.sample(EVENTS, 8)):
            b = Block(i, ev, prev)
            self.blocks.append(b)
            prev = b.hash
        self._save()

    def _save(self):
        self._snap = [{"d":dict(b.data),"h":b.hash,"p":b.prev_hash}
                      for b in self.blocks]

    def broken(self): return [b.index for b in self.blocks if not b.valid()]

    # ── Ataques hacker ───────────────────────────────────────────────────────
    def tamper(self, idx, val):
        if not (0 <= idx < len(self.blocks)): return False,"Bloque inexistente."
        b = self.blocks[idx]
        if b.protected: return False,"🛡️ Bloque protegido."
        b.data["valor"] = val
        b.tampered = True
        return True, f"Bloque {idx} alterado → valor={val}"

    def add_fake(self, val):
        lh = self.blocks[-1].hash
        fd = {"animal":"👤 ???","action":"dato falso","valor":val}
        b  = Block(len(self.blocks), fd, lh)
        b.fake = True; b.tampered = True
        b.hash = "FAKE" + b.hash[4:]
        self.blocks.append(b)
        return True, f"Bloque falso #{b.index} agregado."

    def mirror(self, idx):
        if not (1 <= idx < len(self.blocks)): return False,"Necesitás bloque > 0."
        b = self.blocks[idx]
        if b.protected: return False,"🛡️ Bloque protegido."
        b.hash = self.blocks[idx-1].hash
        b.tampered = True
        return True, f"Mirror en bloque {idx}: sello copiado."

    # ── Defensas nerd ────────────────────────────────────────────────────────
    def fix(self, idx):
        if not (0 <= idx < len(self.blocks)): return False,"Bloque inexistente."
        b = self.blocks[idx]
        ph = self.blocks[idx-1].hash if idx > 0 else "0"*64
        b.prev_hash = ph
        b.hash = _hash(idx, b.data, ph)
        b.tampered = False; b.fake = False
        for j in range(idx+1, len(self.blocks)):
            self.blocks[j].prev_hash = self.blocks[j-1].hash
            self.blocks[j].hash = _hash(j, self.blocks[j].data, self.blocks[j].prev_hash)
        return True, f"Bloque {idx} reparado. Cadena recalculada ✓"

    def protect(self, idx):
        if not (0 <= idx < len(self.blocks)): return False,"Bloque inexistente."
        self.blocks[idx].protected = True
        return True, f"Bloque {idx} protegido 🛡️"

    def unprotect(self, idx):
        if 0 <= idx < len(self.blocks):
            self.blocks[idx].protected = False

    def rewind(self):
        for b, s in zip(self.blocks, self._snap):
            b.data = dict(s["d"]); b.hash = s["h"]
            b.prev_hash = s["p"]; b.tampered = False
            b.fake = False; b.protected = False
        self.blocks = self.blocks[:len(self._snap)]
        return "Cadena restaurada al estado inicial ⏪"

    def trace(self, idx):
        if not (0 <= idx < len(self.blocks)): return "Bloque inexistente."
        b = self.blocks[idx]
        if not b.tampered: return f"Bloque {idx}: sin alteraciones detectadas."
        return (f"TRAZA bloque {idx}:\n"
                f"  Animal : {b.data.get('animal','?')}\n"
                f"  Original: {b._orig.get('valor','?')}\n"
                f"  Actual  : {b.data.get('valor','?')}\n"
                f"  Tipo    : {'FALSO' if b.fake else 'ALTERADO'}")

    def to_list(self, reveal=False):
        return [b.as_dict(reveal) for b in self.blocks]

# ── Jugador ───────────────────────────────────────────────────────────────────
class Player:
    def __init__(self, role, alias):
        self.role    = role
        self.alias   = alias
        self.xp      = 0
        self.hp      = 100
        self.cds     : dict[str,float] = {}
        self.log     : list[str] = []
        self.skills  = HACKER_SKILLS if role=="hacker" else NERD_SKILLS

    def unlocked(self): return [s for s in self.skills if s["xp"] <= self.xp]
    def locked(self):   return [s for s in self.skills if s["xp"] > self.xp]

    def cd_ok(self, sid):
        rem = self.cds.get(sid,0) - time.time()
        return (rem <= 0), max(0, rem)

    def use(self, sid):
        for s in self.skills:
            if s["id"]==sid and s["cd"]>0:
                self.cds[sid] = time.time() + s["cd"]

    def gain_xp(self, n, why=""):
        self.xp += n
        self.log.append(f"+{n} XP  {why}")
        # Notificar desbloqueo
        newly = []
        for s in self.skills:
            if s["xp"] == 0: continue
            if self.xp >= s["xp"] and self.xp - n < s["xp"]:
                newly.append(s)
        return newly

    def lose_hp(self, n, why=""):
        self.hp = max(0, self.hp - n)
        self.log.append(f"-{n} HP  {why}")

    def to_dict(self):
        cds_rem = {k: max(0,round(v-time.time())) for k,v in self.cds.items()}
        return {
            "alias":    self.alias,
            "role":     self.role,
            "xp":       self.xp,
            "hp":       self.hp,
            "unlocked": [s["id"] for s in self.unlocked()],
            "locked":   [{"id":s["id"],"xp":s["xp"]} for s in self.locked()],
            "cds":      cds_rem,
        }

# ── Partida ───────────────────────────────────────────────────────────────────
class Game:
    def __init__(self, room_id):
        self.room_id  = room_id
        self.chain    = Chain()
        self.players  : dict[str, Player] = {}  # sid → Player
        self.started  = False
        self.over     = False
        self.winner   = None
        self.freeze_until = 0.0
        self.bombs    : list[dict] = []
        self.events   : list[dict] = []
        self.created  = time.time()

    # Roles disponibles
    def available_roles(self):
        taken = {p.role for p in self.players.values()}
        return [r for r in ["hacker","nerd"] if r not in taken]

    def add_player(self, sid, role, alias):
        self.players[sid] = Player(role, alias)
        self._ev(f"⚡ {alias} entró como {'🧑‍💻 Hacker' if role=='hacker' else '🤓 Nerd'}", "system")
        if len(self.players) == 2:
            self.started = True
            self._ev("═══════ ¡PARTIDA INICIADA! ═══════", "system")

    def _ev(self, msg, kind="info"):
        self.events.append({"t": datetime.now().strftime("%H:%M:%S"),
                            "msg": msg, "kind": kind})
        if len(self.events) > 80: self.events = self.events[-80:]

    def frozen(self): return time.time() < self.freeze_until

    def tick_bombs(self):
        fired = []; keep = []
        for b in self.bombs:
            if time.time() >= b["at"]:
                ok, msg = self.chain.tamper(b["idx"], b["val"])
                if ok:
                    fired.append(f"💣 BOOM en bloque {b['idx']}!")
                    self._ev(f"💣 BOOM en bloque {b['idx']}!", "hack")
            else:
                keep.append(b)
        self.bombs = keep
        return fired

    def check_win(self):
        """HP a cero = pierde."""
        for sid, p in self.players.items():
            if p.hp <= 0:
                other = next((q for q in self.players.values() if q is not p), None)
                self.winner = other.alias if other else "Nadie"
                self.over   = True
                self._ev(f"🏆 ¡{self.winner} ganó la partida!", "system")
                return True
        return False

    # ── Procesador de comandos ────────────────────────────────────────────────
    def cmd(self, sid, raw) -> list[str]:
        if sid not in self.players:
            return ["No estás en esta partida."]
        if not self.started:
            return ["Esperando al otro jugador..."]
        if self.over:
            return [f"Partida terminada. Ganó: {self.winner}"]

        p     = self.players[sid]
        enemy = next((q for q in self.players.values() if q is not p), None)
        parts = raw.strip().split()
        if not parts: return [""]
        c, args = parts[0].lower(), parts[1:]
        out = []

        # ── Universales ──────────────────────────────────────────────────────
        if c == "help":
            out += self._help(p)

        elif c == "skills":
            out += self._skills_panel(p)

        elif c == "chain":
            out += self._show_chain(p)

        elif c == "status":
            out += self._status(p, enemy)

        elif c == "log":
            n = int(args[0]) if args and args[0].isdigit() else 8
            for e in self.events[-n:]:
                out.append(f"[{e['t']}] {e['msg']}")

        # ── Hacker ───────────────────────────────────────────────────────────
        elif p.role == "hacker":
            out += self._hacker_cmd(p, enemy, c, args)

        # ── Nerd ─────────────────────────────────────────────────────────────
        elif p.role == "nerd":
            out += self._nerd_cmd(p, enemy, c, args)

        else:
            out.append(f"Comando '{c}' desconocido. Escribí 'help'.")

        self.check_win()
        return out

    # ── Help ─────────────────────────────────────────────────────────────────
    def _help(self, p):
        lines = [
            f"══════ AYUDA — {p.alias} ({p.role.upper()}) ══════",
            "",
            "  Comandos siempre disponibles:",
            "    chain         → ver la cadena de bloques",
            "    scan          → ver qué bloques están rotos",
            "    status        → ver HP y XP de ambos jugadores",
            "    skills        → ver habilidades y cooldowns",
            "    log           → ver historial de la partida",
            "    help          → esta ayuda",
            "",
        ]
        if p.role == "hacker":
            lines += ["  Tus comandos de ataque:"]
            for s in p.skills:
                lock = s["xp"] > p.xp
                icon = "🔒" if lock else "✅"
                lines.append(f"    {icon} {s['icon']} {s['uso']}")
                if not lock:
                    lines.append(f"         ↳ {s['desc']}")
        else:
            lines += ["  Tus comandos de defensa:"]
            for s in p.skills:
                lock = s["xp"] > p.xp
                icon = "🔒" if lock else "✅"
                lines.append(f"    {icon} {s['icon']} {s['uso']}")
                if not lock:
                    lines.append(f"         ↳ {s['desc']}")
        lines += ["", "  Ejemplo: escribí  ghost 3 999  y presioná ENTER"]
        return lines

    # ── Skills panel ─────────────────────────────────────────────────────────
    def _skills_panel(self, p):
        lines = [f"══ Habilidades de {p.alias} ══  XP:{p.xp}  HP:{p.hp}",""]
        for s in p.skills:
            lock = s["xp"] > p.xp
            ok, rem = p.cd_ok(s["id"])
            if lock:
                lines.append(f"  🔒 {s['icon']} {s['name']}  (necesitás {s['xp']} XP)")
            elif not ok:
                lines.append(f"  ⏳ {s['icon']} {s['name']}  cooldown {rem:.0f}s")
            else:
                lines.append(f"  ✅ {s['icon']} {s['name']}  [{s['uso']}]")
                lines.append(f"      {s['desc']}")
        if p.log:
            lines += ["", "  Historial reciente:"]
            for h in p.log[-4:]: lines.append(f"    {h}")
        return lines

    # ── Chain display ─────────────────────────────────────────────────────────
    def _show_chain(self, p):
        lines = ["══ Cadena del Jardín ══",""]
        for b in self.chain.blocks:
            ok   = b.valid()
            mark = "✓" if ok else "✗"
            prot = " 🛡️" if b.protected else ""
            lines.append(
                f"  [{b.index}] {mark} {b.data.get('animal','?')} | "
                f"{b.data.get('action','?')} → {b.data.get('valor','?')} | "
                f"hash:{_short(b.hash)}{prot}"
            )
        broken = self.chain.broken()
        if broken:
            lines += ["", f"  ⚠️  Bloques rotos: {broken}"]
        else:
            lines += ["", "  ✅ Todos los bloques son válidos"]
        return lines

    # ── Status ────────────────────────────────────────────────────────────────
    def _status(self, p, enemy):
        lines = ["══ Estado de la partida ══",""]
        for pl in [p, enemy]:
            if not pl: continue
            bar_hp = "█"*max(0,pl.hp//10) + "░"*(10-max(0,pl.hp//10))
            bar_xp = "★"*min(5, pl.xp//60)
            lines.append(f"  {pl.alias} ({pl.role})")
            lines.append(f"    ❤️  [{bar_hp}] {pl.hp} HP")
            lines.append(f"    ⭐ [{bar_xp}] {pl.xp} XP")
            lines.append("")
        broken = self.chain.broken()
        lines.append(f"  🔗 Cadena: {len(self.chain.blocks)} bloques | "
                     f"{'⚠️ '+str(len(broken))+' rotos' if broken else '✅ íntegra'}")
        if self.frozen():
            lines.append(f"  ❄️  Cadena CONGELADA ({self.freeze_until-time.time():.0f}s)")
        if self.bombs:
            lines.append(f"  💣 Bombas activas: {len(self.bombs)}")
        return lines

    # ── Comandos Hacker ───────────────────────────────────────────────────────
    def _hacker_cmd(self, p, enemy, c, args):
        out = []

        if c == "ghost":
            ok, rem = p.cd_ok("ghost")
            if not ok: return [f"⏳ Ghost en cooldown ({rem:.0f}s)"]
            if len(args) < 2: return ["Uso: ghost <bloque> <valor>  ej: ghost 3 999"]
            try: idx, val = int(args[0]), int(args[1])
            except: return ["Los argumentos tienen que ser números. ej: ghost 3 999"]
            if self.frozen(): return ["❄️ La cadena está congelada. No podés atacar."]
            ok2, msg = self.chain.tamper(idx, val)
            if ok2:
                p.use("ghost")
                newly = p.gain_xp(20, "ghost exitoso")
                if enemy: enemy.lose_hp(15, "ghost del hacker")
                self._ev(f"👻 {p.alias} usó Ghost en bloque {idx}", "hack")
                out += [f"👻 {msg}", f"  → +20 XP  | -{15} HP al Nerd"]
                out += self._unlock_msgs(newly)
            else:
                out.append(f"Ghost falló: {msg}")

        elif c == "smoke":
            if not self._check_skill(p, "smoke", out): return out
            if len(args) < 1: return ["Uso: smoke <valor>  ej: smoke 7"]
            try: val = int(args[0])
            except: return ["El valor tiene que ser un número. ej: smoke 7"]
            if self.frozen(): return ["❄️ Cadena congelada."]
            ok2, msg = self.chain.add_fake(val)
            if ok2:
                p.use("smoke")
                newly = p.gain_xp(25, "smoke screen")
                if enemy: enemy.lose_hp(10, "smoke del hacker")
                self._ev(f"💨 {p.alias} usó Smoke Screen", "hack")
                out += [f"💨 {msg}", "  → +25 XP  | -10 HP al Nerd"]
                out += self._unlock_msgs(newly)

        elif c == "mirror":
            if not self._check_skill(p, "mirror", out): return out
            if len(args) < 1: return ["Uso: mirror <bloque>  ej: mirror 5"]
            try: idx = int(args[0])
            except: return ["Necesitás un número de bloque. ej: mirror 5"]
            if self.frozen(): return ["❄️ Cadena congelada."]
            ok2, msg = self.chain.mirror(idx)
            if ok2:
                p.use("mirror")
                newly = p.gain_xp(30, "mirror")
                if enemy: enemy.lose_hp(12, "mirror del hacker")
                self._ev(f"🪞 {p.alias} usó Mirror en bloque {idx}", "hack")
                out += [f"🪞 {msg}", "  → +30 XP  | -12 HP al Nerd"]
                out += self._unlock_msgs(newly)
            else:
                out.append(f"Mirror falló: {msg}")

        elif c == "timebomb":
            if not self._check_skill(p, "timebomb", out): return out
            if len(args) < 2: return ["Uso: timebomb <bloque> <valor>  ej: timebomb 4 777"]
            try: idx, val = int(args[0]), int(args[1])
            except: return ["Necesitás dos números. ej: timebomb 4 777"]
            if self.frozen(): return ["❄️ Cadena congelada."]
            self.bombs.append({"idx":idx,"val":val,"at":time.time()+15})
            p.use("timebomb")
            newly = p.gain_xp(15, "timebomb plantada")
            self._ev(f"💣 {p.alias} plantó timebomb en bloque {idx}", "hack")
            out += [f"💣 Timebomb plantada en bloque {idx}. Explota en 15s.",
                    "  → +15 XP"]
            out += self._unlock_msgs(newly)

        elif c == "cascade":
            if not self._check_skill(p, "cascade", out): return out
            if len(args) < 2: return ["Uso: cascade <bloque1> <bloque2>  ej: cascade 2 7"]
            try: i1, i2 = int(args[0]), int(args[1])
            except: return ["Necesitás dos números de bloque. ej: cascade 2 7"]
            if self.frozen(): return ["❄️ Cadena congelada."]
            r1 = self.chain.tamper(i1, random.randint(100,999))
            r2 = self.chain.tamper(i2, random.randint(100,999))
            if r1[0] or r2[0]:
                p.use("cascade")
                newly = p.gain_xp(45, "cascade")
                if enemy: enemy.lose_hp(20, "cascade del hacker")
                self._ev(f"🌊 {p.alias} usó Cascade en bloques {i1} y {i2}", "hack")
                out += [f"🌊 Cascade: bloques {i1} y {i2} alterados.",
                        "  → +45 XP  | -20 HP al Nerd"]
                out += self._unlock_msgs(newly)
            else:
                out.append("Cascade falló: ambos bloques protegidos.")

        else:
            out.append(f"'{c}' no es un comando válido. Escribí 'help'.")

        return out

    # ── Comandos Nerd ─────────────────────────────────────────────────────────
    def _nerd_cmd(self, p, enemy, c, args):
        out = []

        if c in ("scan", "scan"):
            broken = self.chain.broken()
            if not broken:
                out.append("🔍 Scan: ✅ Todos los bloques son válidos. ¡Cadena sana!")
            else:
                out.append(f"🔍 Scan: ⚠️  Bloques rotos → {broken}")
                out.append("   Usá  fix <N>  para reparar cada uno.")
            newly = p.gain_xp(5, "scan")
            out += self._unlock_msgs(newly)

        elif c == "fix":
            ok, rem = p.cd_ok("fix")
            if not ok: return [f"⏳ Fix en cooldown ({rem:.0f}s)"]
            if not args: return ["Uso: fix <bloque>  ej: fix 3"]
            try: idx = int(args[0])
            except: return ["Necesitás el número del bloque. ej: fix 3"]
            ok2, msg = self.chain.fix(idx)
            if ok2:
                p.use("fix")
                newly = p.gain_xp(30, "fix exitoso")
                if enemy: enemy.lose_hp(20, "fix del nerd")
                self._ev(f"🔧 {p.alias} reparó bloque {idx}", "nerd")
                out += [f"🔧 {msg}", f"  → +30 XP  | -20 HP al Hacker"]
                out += self._unlock_msgs(newly)
            else:
                out.append(f"Fix falló: {msg}")

        elif c == "freeze":
            if not self._check_skill(p, "freeze", out): return out
            self.freeze_until = time.time() + 20
            p.use("freeze")
            newly = p.gain_xp(20, "freeze")
            if enemy: enemy.lose_hp(10, "freeze del nerd")
            self._ev(f"❄️ {p.alias} congeló la cadena por 20s", "nerd")
            out += ["❄️ ¡Cadena congelada! El Hacker no puede atacar por 20s.",
                    "  → +20 XP  | -10 HP al Hacker"]
            out += self._unlock_msgs(newly)

        elif c == "shield":
            if not self._check_skill(p, "shield", out): return out
            if not args: return ["Uso: shield <bloque>  ej: shield 5"]
            try: idx = int(args[0])
            except: return ["Necesitás el número del bloque. ej: shield 5"]
            ok2, msg = self.chain.protect(idx)
            if ok2:
                p.use("shield")
                newly = p.gain_xp(15, "shield")
                self._ev(f"🛡️ {p.alias} protegió bloque {idx}", "nerd")
                out += [f"🛡️ {msg}", "  → +15 XP"]
                # Auto-unprotect en 30s (manejado en app.py via tick)
                self.bombs.append({"type":"unshield","idx":idx,"at":time.time()+30})
                out += self._unlock_msgs(newly)
            else:
                out.append(f"Shield falló: {msg}")

        elif c == "rewind":
            if not self._check_skill(p, "rewind", out): return out
            msg = self.chain.rewind()
            p.use("rewind")
            newly = p.gain_xp(50, "rewind")
            if enemy: enemy.lose_hp(30, "rewind del nerd")
            self._ev(f"⏪ {p.alias} usó Rewind", "nerd")
            out += [f"⏪ {msg}", "  → +50 XP  | -30 HP al Hacker"]
            out += self._unlock_msgs(newly)

        elif c == "trace":
            if not self._check_skill(p, "trace", out): return out
            if not args: return ["Uso: trace <bloque>  ej: trace 3"]
            try: idx = int(args[0])
            except: return ["Necesitás el número del bloque. ej: trace 3"]
            msg = self.chain.trace(idx)
            p.use("trace")
            newly = p.gain_xp(10, "trace")
            self._ev(f"🕵️ {p.alias} usó Trace en bloque {idx}", "nerd")
            out += [f"🕵️ {msg}", "  → +10 XP"]
            out += self._unlock_msgs(newly)

        else:
            out.append(f"'{c}' no es un comando válido. Escribí 'help'.")

        return out

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _check_skill(self, p, sid, out) -> bool:
        skill = next((s for s in p.skills if s["id"]==sid), None)
        if not skill: return False
        if skill["xp"] > p.xp:
            out.append(f"🔒 Necesitás {skill['xp']} XP para usar {skill['name']}. (Tenés {p.xp})")
            return False
        ok, rem = p.cd_ok(sid)
        if not ok:
            out.append(f"⏳ {skill['name']} en cooldown. Esperá {rem:.0f}s más.")
            return False
        return True

    def _unlock_msgs(self, newly: list) -> list[str]:
        if not newly: return []
        out = []
        for s in newly:
            out.append(f"")
            out.append(f"  ╔══════════════════════════════╗")
            out.append(f"  ║  🆕 ¡DESBLOQUEASTE {s['name']}! {s['icon']}  ║")
            out.append(f"  ║  {s['desc'][:30]}...  ║")
            out.append(f"  ║  Uso: {s['uso']}  ║")
            out.append(f"  ╚══════════════════════════════╝")
        return out

    def state(self):
        return {
            "started":  self.started,
            "over":     self.over,
            "winner":   self.winner,
            "frozen":   self.frozen(),
            "freeze_rem": max(0, round(self.freeze_until - time.time())),
            "bombs":    len(self.bombs),
            "players":  {sid: p.to_dict() for sid,p in self.players.items()},
            "chain":    self.chain.to_list(),
            "events":   self.events[-15:],
        }

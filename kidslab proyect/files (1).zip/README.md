# 🕹️ Hackers vs Nerds

Juego multijugador educativo de terminal para aprender cómo funciona una cadena de bloques.
Dos jugadores, dos roles, comandos reales de Python.

---

## Arrancar

```bash
cd hackers_vs_nerds
pip install -r requirements.txt
python app.py
# → http://localhost:5051
```

Para jugar por internet, usá ngrok o Tailscale Funnel:
```bash
# Con ngrok (gratis):
ngrok http 5051
# Compartís la URL pública con tu amigo
```

---

## Cómo se juega

### El Hacker 🧑‍💻
Altera bloques de la cadena sin que el Nerd lo note. Cada ataque exitoso quita HP al Nerd.
Si el HP del Nerd llega a 0 → gana el Hacker.

### El Nerd 🤓
Detecta y repara los bloques rotos. Cada reparación exitosa quita HP al Hacker.
Si el HP del Hacker llega a 0 → gana el Nerd.

---

## Comandos

### Universales (todos los jugadores)
| Comando  | Qué hace                        |
|----------|---------------------------------|
| `help`   | Ver todos los comandos          |
| `chain`  | Ver la cadena de bloques        |
| `scan`   | Ver qué bloques están rotos     |
| `status` | Ver HP y XP de ambos jugadores  |
| `skills` | Ver habilidades y cooldowns     |
| `log`    | Ver historial de la partida     |

### Hacker
| Comando                | XP necesario | Qué hace                              |
|------------------------|--------------|---------------------------------------|
| `ghost <N> <valor>`    | 0            | Altera el valor del bloque N          |
| `smoke <valor>`        | 40           | Agrega un bloque falso al final       |
| `mirror <N>`           | 90           | Copia el sello del bloque anterior    |
| `timebomb <N> <valor>` | 160          | Trampa que explota en 15 segundos     |
| `cascade <N1> <N2>`    | 270          | Altera dos bloques a la vez           |

### Nerd
| Comando     | XP necesario | Qué hace                              |
|-------------|--------------|---------------------------------------|
| `scan`      | 0            | Muestra qué bloques están rotos       |
| `fix <N>`   | 0            | Repara el hash del bloque N           |
| `freeze`    | 40           | El Hacker no puede atacar por 20s     |
| `shield <N>`| 90           | Protege un bloque por 30s             |
| `rewind`    | 160          | Restaura la cadena al estado inicial  |
| `trace <N>` | 270          | Revela exactamente qué cambió         |

---

## Seguridad implementada

### Sin chat libre
El campo de texto solo acepta comandos del juego. No hay forma de escribir texto libre.
El servidor sanitiza toda entrada: solo acepta alfanuméricos + espacios.

### Sin datos personales
Los jugadores reciben apodos automáticos generados al azar (ej: Zorro-47, Búho-12).
No se piden nombres, edades, ni ningún dato personal.

### Salas efímeras
Los códigos de sala expiran automáticamente en 30 minutos.
Máximo 2 jugadores por sala. No hay lobbies públicos ni listas de salas.

### Sin persistencia
Nada se guarda entre sesiones. Cuando los jugadores se van, la sala desaparece.

### Input sanitizado server-side
```python
raw = str(data.get("cmd",""))[:80].strip()
raw = "".join(c for c in raw if c.isalnum() or c in " _-")
```
Máximo 80 caracteres. Solo alfanuméricos, guiones y espacios.

---

## Arquitectura

```
hvn/
├── app.py          # Flask + SocketIO · gestión de salas y eventos
├── game_engine.py  # Lógica del juego: cadena, jugadores, comandos, XP
├── requirements.txt
├── templates/
│   └── index.html  # Terminal estilo shell-in-a-box
└── README.md
```

---

## Lo que aprenden los chicos jugando

- **Qué es un hash**: si cambiás un dato, el hash cambia y "se rompe" la cadena
- **Inmutabilidad**: no podés cambiar un bloque sin afectar todos los siguientes
- **Comandos de terminal**: escriben comandos reales con argumentos
- **Pensamiento lógico**: tienen que razonar qué bloque atacar / defender
- **XP y progresión**: las habilidades avanzadas se desbloquean ganando experiencia

---

MIT License · ramigardner · moteroenchilado@gmail.com

#!/usr/bin/env python3
"""
app.py — Hackers vs Nerds · Servidor principal
Salas efímeras, sin chat libre, sin datos personales.
"""
import eventlet
eventlet.monkey_patch()

import random, string, time
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
from game_engine import Game, random_alias

app = Flask(__name__)
app.config["SECRET_KEY"] = "hvn-kids-safe-2025"
CORS(app)
sio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

# ── Salas activas ─────────────────────────────────────────────────────────────
rooms: dict[str, Game] = {}   # room_code → Game
sid_room: dict[str, str] = {} # sid → room_code
ROOM_TTL = 1800  # 30 minutos

def gen_code():
    while True:
        code = "".join(random.choices(string.digits, k=6))
        if code not in rooms:
            return code

def cleanup():
    """Elimina salas vencidas."""
    now = time.time()
    dead = [c for c, g in rooms.items() if now - g.created > ROOM_TTL]
    for c in dead:
        del rooms[c]

# ── Tick global: timebombs, unshields ────────────────────────────────────────
def global_tick():
    while True:
        eventlet.sleep(1)
        for code, game in list(rooms.items()):
            if not game.started or game.over:
                continue
            # Detonar bombas
            fired = game.tick_bombs()
            if fired:
                sio.emit("game_state", game.state(), room=code)
                for msg in fired:
                    sio.emit("terminal_out", {"lines": [msg], "kind":"hack"}, room=code)
            # Unshield expirado
            keep = []
            for b in game.bombs:
                if b.get("type") == "unshield" and time.time() >= b["at"]:
                    game.chain.unprotect(b["idx"])
                    sio.emit("terminal_out",
                             {"lines":[f"🛡️ Shield del bloque {b['idx']} expiró."],
                              "kind":"nerd"}, room=code)
                    sio.emit("game_state", game.state(), room=code)
                else:
                    keep.append(b)
            game.bombs = keep

sio.start_background_task(global_tick)

# ── Rutas HTTP ────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

# ── SocketIO ──────────────────────────────────────────────────────────────────
@sio.on("connect")
def on_connect():
    cleanup()
    emit("connected", {"sid": request.sid})

@sio.on("disconnect")
def on_disconnect():
    sid = request.sid
    if sid in sid_room:
        code = sid_room.pop(sid)
        if code in rooms:
            game = rooms[code]
            p = game.players.get(sid)
            if p:
                game._ev(f"⚠️ {p.alias} se desconectó.", "system")
                del game.players[sid]
            sio.emit("game_state", game.state(), room=code)

@sio.on("create_room")
def on_create(data):
    cleanup()
    role  = data.get("role", "hacker")
    code  = gen_code()
    game  = Game(code)
    alias = random_alias(role)
    rooms[code] = game
    game.add_player(request.sid, role, alias)
    sid_room[request.sid] = code
    join_room(code)
    emit("room_created", {"code": code, "alias": alias, "role": role})
    emit("game_state", game.state())

@sio.on("join_room")
def on_join(data):
    code = str(data.get("code","")).strip()
    if code not in rooms:
        emit("error", {"msg": f"Sala {code} no existe o ya expiró."})
        return
    game = rooms[code]
    if game.over:
        emit("error", {"msg": "Esa partida ya terminó."})
        return
    avail = game.available_roles()
    if not avail:
        emit("error", {"msg": "La sala está llena."})
        return
    role  = avail[0]
    alias = random_alias(role)
    game.add_player(request.sid, role, alias)
    sid_room[request.sid] = code
    join_room(code)
    emit("room_joined", {"code": code, "alias": alias, "role": role})
    sio.emit("game_state", game.state(), room=code)
    sio.emit("terminal_out",
             {"lines": [f"⚡ {alias} entró como {'🤓 Nerd' if role=='nerd' else '🧑‍💻 Hacker'}!"],
              "kind": "system"}, room=code)

@sio.on("command")
def on_command(data):
    sid = request.sid
    if sid not in sid_room:
        emit("terminal_out", {"lines":["No estás en ninguna sala."], "kind":"error"})
        return
    code = sid_room[sid]
    if code not in rooms:
        emit("terminal_out", {"lines":["La sala ya no existe."], "kind":"error"})
        return
    game = rooms[code]

    # Sanitizar: solo texto plano, sin HTML, max 80 chars
    raw = str(data.get("cmd",""))[:80].strip()
    # Filtrar caracteres raros (solo alfanuméricos + espacios + guiones)
    raw = "".join(c for c in raw if c.isalnum() or c in " _-")

    if not raw:
        return

    p = game.players.get(sid)
    role_kind = "hack" if p and p.role=="hacker" else "nerd"

    # Echo del comando
    emit("terminal_out", {
        "lines": [f"$ {raw}"],
        "kind":  role_kind
    })

    # Ejecutar
    out = game.cmd(sid, raw)

    # Output al jugador
    if out:
        emit("terminal_out", {"lines": out, "kind": role_kind})

    # Broadcast estado a toda la sala
    sio.emit("game_state", game.state(), room=code)

    # Si la partida terminó, notificar
    if game.over:
        sio.emit("game_over", {"winner": game.winner}, room=code)

@sio.on("request_state")
def on_state():
    sid = request.sid
    if sid in sid_room:
        code = sid_room[sid]
        if code in rooms:
            emit("game_state", rooms[code].state())

if __name__ == "__main__":
    print("🕹️  Hackers vs Nerds — arrancando...")
    print("   → http://localhost:5051")
    sio.run(app, host="0.0.0.0", port=5051, debug=False)
